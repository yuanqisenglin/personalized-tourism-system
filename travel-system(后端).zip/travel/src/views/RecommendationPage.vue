<template>
  <!-- No changes to template section -->
</template>

<script>
import axios from 'axios';
import { ref } from 'vue';

export default {
  setup() {
    const recommendedSpots = ref([]);
    const recommendedSchools = ref([]);
    const recommendedFoods = ref([]);
    const recommendedDiaries = ref([]);
    const selectedCategory = ref('');

    const fetchCategoryRecommendations = async (category) => {
      try {
        const response = await axios.get(endpoint);
        const data = response.data;
        
        // 根据分类将数据赋值给对应的推荐列表
        switch (category) {
          case 'spots':
            recommendedSpots.value = data || [];
            break;
          case 'schools':
            recommendedSchools.value = data || [];
            break;
          case 'foods':
            recommendedFoods.value = (data || []).map(item => ({
              ...item,
              cuisine: item.cuisine_type,
              restaurant: item.restaurantname
            }));
            break;
          case 'diaries':
            recommendedDiaries.value = data || [];
            break;
        }
        selectedCategory.value = category; // 更新选中的分类
      } catch (error) {
        console.error('Error fetching recommendations:', error);
      }
    };

    return {
      recommendedSpots,
      recommendedSchools,
      recommendedFoods,
      recommendedDiaries,
      selectedCategory,
      fetchCategoryRecommendations
    };
  }
};
</script>

<style>
  /* No changes to style section */
</style> 