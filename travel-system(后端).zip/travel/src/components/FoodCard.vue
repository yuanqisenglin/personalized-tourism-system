<h3>
  <span class="top-rank">{{ rank }}</span> {{ food.name }}
</h3>
<p>菜系: {{ food.cuisine || food.cuisine_type }}</p>
<p>饭店: {{ food.restaurantname }}</p> 