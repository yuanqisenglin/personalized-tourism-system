package com.example.demo.login;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name="tb_user")
public class user {
    @ID
    @Column(name="user_id")
    private String Id;

    @Column(name = "username", unique = true)  // username 映射为实体类中的 username，且唯一
    private String username;

    @Column(name = "password")
    private String password;
}
