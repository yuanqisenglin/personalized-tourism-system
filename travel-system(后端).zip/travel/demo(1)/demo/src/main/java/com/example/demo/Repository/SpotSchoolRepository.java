/*package com.example.demo.Repository;

import com.example.demo.dao.SpotSchool;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SpotSchoolRepository extends JpaRepository<SpotSchool, Long> {

//    // 根据 type 筛选数据并按 rating 或 popularity 排序
//    @Query("SELECT s FROM SpotSchool s WHERE (:type IS NULL OR s.type = :type) " +
//            "ORDER BY " +
//            "CASE WHEN :sortBy = 'rating' THEN s.rating ELSE NULL END DESC, " +
//            "CASE WHEN :sortBy = 'popularity' THEN s.popularity ELSE NULL END DESC,"
//            +
//            "s.id ASC")
    List<SpotSchool> findByType(
           /* @Param("type") *//*String type,
           /* @Param("sortBy")*//* Sort sort
    );

}*/



package com.example.demo.Repository;

import com.example.demo.Entity.SpotSchool;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SpotSchoolRepository extends JpaRepository<SpotSchool, Long> {

//    /**
//     * 筛选、排序、搜索方法
//     * @param type 景点类型（spot/school），可为空
//     * @param searchKeyword 搜索关键词，可为空
//     * @param sort 排序规则
//     * @return 符合条件的数据列表
//     */
    /*@Query("SELECT s FROM SpotSchool s WHERE (:type IS NULL OR s.type = :type)")
    List<SpotSchool> findByType(@Param("type") String type, Sort sort);*/

    @Query("SELECT s FROM SpotSchool s " +
            "WHERE (:type IS NULL OR s.type = :type) " +
            "AND (:searchKeyword IS NULL OR LOWER(s.name) LIKE LOWER(CONCAT('%', :searchKeyword, '%')) " +
            "OR LOWER(s.description) LIKE LOWER(CONCAT('%', :searchKeyword, '%')))")
    List<SpotSchool> findByCriteria(
            @Param("type") String type,
            @Param("searchKeyword") String searchKeyword,
            Sort sort
    );

    SpotSchool findByName(String name);
}



