package com.example.demo.Repository;

import com.example.demo.Entity.UserBehavior;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface UserBehaviorRepository extends JpaRepository<UserBehavior, Long> {
    // 获取用户的所有行为记录
    List<UserBehavior> findByUserId(String userId);

    // 获取用户特定类型的行为记录
    List<UserBehavior> findByUserIdAndTargetType(String userId, String targetType);

    // 获取用户特定类型和特定行为类型的记录
    List<UserBehavior> findByUserIdAndTargetTypeAndBehaviorType(
            String userId,
            String targetType,
            UserBehavior.BehaviorType behaviorType
    );

    // 获取用户最近的行为记录
    List<UserBehavior> findByUserIdOrderByBehaviorTimeDesc(String userId);

    // 获取用户特定时间范围内的行为记录
    List<UserBehavior> findByUserIdAndBehaviorTimeBetween(
            String userId,
            LocalDateTime startTime,
            LocalDateTime endTime
    );

    // 获取用户对特定内容的评论次数
    @Query("SELECT COUNT(b) FROM UserBehavior b WHERE b.userId = :userId AND b.targetType = :targetType AND b.behaviorType = 'comment'")
    long countUserComments(@Param("userId") String userId, @Param("targetType") String targetType);

    // 获取用户最近浏览的内容ID列表
    @Query("SELECT b.targetId FROM UserBehavior b WHERE b.userId = :userId AND b.behaviorType = 'view' ORDER BY b.behaviorTime DESC")
    List<Long> findRecentlyViewedContentIds(@Param("userId") String userId);

    // 获取用户最常浏览的内容类型
    @Query("SELECT b.targetType, COUNT(b) as count FROM UserBehavior b WHERE b.userId = :userId AND b.behaviorType = 'view' GROUP BY b.targetType ORDER BY count DESC")
    List<Object[]> findMostViewedContentTypes(@Param("userId") String userId);

    // 获取用户对特定内容的互动次数（浏览+评论）
    @Query("SELECT COUNT(b) FROM UserBehavior b WHERE b.userId = :userId AND b.targetId = :targetId")
    long countUserInteractions(@Param("userId") String userId, @Param("targetId") Long targetId);
}