package com.example.demo.Dto;

public class FoodDTO {
    private Long id;
    private String name;
    private String cuisine_type;
    private int popularity;
    private double rating;
    private String restaurantname;
    private String type;
    private Double distance; // 只返回一个统一的 distance 字段

    public FoodDTO(Long id, String name, String cuisine_type, int popularity,
                   double rating, String restaurantname, String type, Double distance) {
        this.id = id;
        this.name = name;
        this.cuisine_type = cuisine_type;
        this.popularity = popularity;
        this.rating = rating;
        this.restaurantname = restaurantname;
        this.type = type;
        this.distance = distance;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPopularity() {
        return popularity;
    }

    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    public String getCuisine_type() {
        return cuisine_type;
    }

    public void setCuisine_type(String cuisine_type) {
        this.cuisine_type = cuisine_type;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getRestaurantname() {
        return restaurantname;
    }

    public void setRestaurantname(String restaurantname) {
        this.restaurantname = restaurantname;
    }
// ✅ 记得添加 getter（或者用 Lombok @Getter 简化）

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }
}
