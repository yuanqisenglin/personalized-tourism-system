package com.example.demo.Service;

import com.example.demo.Dto.FoodDTO;
import com.example.demo.Entity.Food;
import java.util.List;

public interface FoodService {
    List<FoodDTO> getFoodData(String type, String sortBy, String searchKeyword, String location);

    // 获取单个美食信息
    Food getFoodById(Long id);

    // 更新美食信息
    Food updateFood(Food food);
}
