package com.example.demo.Service;

import com.example.demo.Entity.Rating;
import com.example.demo.Repository.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RatingServiceImpl implements RatingService {
    @Autowired
    private RatingRepository ratingRepository;

    @Override
    public Rating addRating(Rating rating) {
        return ratingRepository.save(rating);
    }

    @Override
    public List<Rating> getRatingsByDiaryId(Long diaryId) {
        return ratingRepository.findByDiaryId(diaryId);
    }

    @Override
    public List<Rating> getRatingsByDiaryIdAndUserId(Long diaryId, String userId) {
        return ratingRepository.findByDiaryIdAndUserId(diaryId, userId);
    }

    @Override
    public double getAverageRating(Long diaryId) {
        List<Rating> ratings = ratingRepository.findByDiaryId(diaryId);
        if (ratings.isEmpty()) return 0.0;
        return ratings.stream().mapToInt(Rating::getRating).average().orElse(0.0);
    }
}