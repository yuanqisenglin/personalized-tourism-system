package com.example.demo.Util;

import java.io.File;

public class ImageCompressionUtil {

    /**
     * 验证压缩是否成功（通过比较文件大小，仅用于日志）
     * @param originalFilePath 原始文件路径
     * @param compressedFilePath 压缩后文件路径
     * @return true 表示成功或日志参考，不中断流程
     */
    public static boolean verifyCompression(String originalFilePath, String compressedFilePath) {
        File originalFile = new File(originalFilePath);
        File compressedFile = new File(compressedFilePath);

        if (!originalFile.exists()) {
            System.out.println("原始文件不存在: " + originalFilePath);
            return false;
        }

        if (!compressedFile.exists()) {
            System.out.println("压缩后文件不存在: " + compressedFilePath);
            return false;
        }

        long beforeSize = originalFile.length();
        long afterSize = compressedFile.length();

        System.out.println("压缩前大小: " + beforeSize + " 字节");
        System.out.println("压缩后大小: " + afterSize + " 字节");

        if (afterSize <= beforeSize) {
            System.out.println("压缩成功或无损压缩");
        } else {
            System.out.println("压缩后文件略大（可能为转码格式变更），不认为失败");
        }

        return true; // 不再影响主流程
    }
}
