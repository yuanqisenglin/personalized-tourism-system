package com.example.demo.Controller;

import com.example.demo.Entity.*;
import com.example.demo.Service.RecommendationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/recommendations")
@CrossOrigin(origins = "http://localhost:8080")
public class RecommendationController {

    @Autowired
    private RecommendationService recommendationService;

    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserRecommendations(
            @PathVariable String userId,
            @RequestParam(defaultValue = "5") int limit
    ) {
        try {
            Map<String, Object> recommendations = new HashMap<>();

            // 获取各类推荐
            recommendations.put("spots", recommendationService.getRecommendedSpots(userId, limit));
            recommendations.put("schools", recommendationService.getRecommendedSchools(userId, limit));
            recommendations.put("foods", recommendationService.getRecommendedFoods(userId, limit));
            recommendations.put("diaries", recommendationService.getRecommendedDiaries(userId, limit));

            // 获取用户兴趣标签
            recommendations.put("interests", recommendationService.getUserInterests(userId));

            return ResponseEntity.ok(recommendations);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取推荐失败：" + e.getMessage());
        }
    }

    @GetMapping("/spots/{userId}")
    public ResponseEntity<?> getSpotRecommendations(
            @PathVariable String userId,
            @RequestParam(defaultValue = "5") int limit
    ) {
        try {
            return ResponseEntity.ok(recommendationService.getRecommendedSpots(userId, limit));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取景点推荐失败：" + e.getMessage());
        }
    }

    @GetMapping("/schools/{userId}")
    public ResponseEntity<?> getSchoolRecommendations(
            @PathVariable String userId,
            @RequestParam(defaultValue = "5") int limit
    ) {
        try {
            return ResponseEntity.ok(recommendationService.getRecommendedSchools(userId, limit));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取学校推荐失败：" + e.getMessage());
        }
    }

    @GetMapping("/foods/{userId}")
    public ResponseEntity<?> getFoodRecommendations(
            @PathVariable String userId,
            @RequestParam(defaultValue = "5") int limit
    ) {
        try {
            return ResponseEntity.ok(recommendationService.getRecommendedFoods(userId, limit));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取美食推荐失败：" + e.getMessage());
        }
    }

    @GetMapping("/diaries/{userId}")
    public ResponseEntity<?> getDiaryRecommendations(
            @PathVariable String userId,
            @RequestParam(defaultValue = "5") int limit
    ) {
        try {
            return ResponseEntity.ok(recommendationService.getRecommendedDiaries(userId, limit));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取旅游日记推荐失败：" + e.getMessage());
        }
    }

    @GetMapping("/interests/{userId}")
    public ResponseEntity<?> getUserInterests(@PathVariable String userId) {
        try {
            return ResponseEntity.ok(recommendationService.getUserInterests(userId));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("获取用户兴趣失败：" + e.getMessage());
        }
    }
}