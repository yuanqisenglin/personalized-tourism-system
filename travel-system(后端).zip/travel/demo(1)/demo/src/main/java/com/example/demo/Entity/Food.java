package com.example.demo.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_food")
public class Food {
    @Id
    @Column(name = "food_id")
    private Long id;

    @Column(name = "food_name")
    private String name;

    @Column(name = "cuisine_type")
    private String cuisine_type;

    @Column(name = "popularity")
    private Integer popularity;

    @Column(name="rating")
    private double rating;

    @Column(name ="restaurant_or_window_name")
    private String restaurantname;

    @Column(name="type")
    private String type;

    @Column(name = "distance_to_school")
    private Double distanceToSchool;

    @Column(name = "distance_to_spot")
    private Double distanceToSpot;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCuisine_type() {
        return cuisine_type;
    }

    public void setCuisine_type(String cuisine_type) {
        this.cuisine_type = cuisine_type;
    }

    public Integer getPopularity() {
        return popularity;
    }

    public void setPopularity(Integer popularity) {
        this.popularity = popularity;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getRestaurantname() {
        return restaurantname;
    }

    public void setRestaurantname(String restaurantname) {
        this.restaurantname = restaurantname;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getDistanceToSchool() {
        return distanceToSchool;
    }

    public void setDistanceToSchool(Double distanceToSchool) {
        this.distanceToSchool = distanceToSchool;
    }

    public Double getDistanceToSpot() {
        return distanceToSpot;
    }

    public void setDistanceToSpot(Double distanceToSpot) {
        this.distanceToSpot = distanceToSpot;
    }
}
