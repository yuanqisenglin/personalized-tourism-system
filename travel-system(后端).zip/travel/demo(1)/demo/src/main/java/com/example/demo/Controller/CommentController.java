package com.example.demo.Controller;
import com.example.demo.Entity.UserBehavior;
import com.example.demo.Entity.Comment;
import com.example.demo.Entity.CommentRequest;
import com.example.demo.Service.CommentService;
import com.example.demo.Service.UserBehaviorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/diary") // <-- 修改为 "/diary"
@CrossOrigin
public class CommentController {

    @Autowired
    private CommentService commentService;
    @Autowired
    private UserBehaviorService userBehaviorService;
    // 添加评论
    @PostMapping("/comment")
    public Map<String, Object> addComment(@RequestBody CommentRequest request) {
        Comment comment = new Comment();
        comment.setDiaryId(request.getDiaryId());
        comment.setCommentContent(request.getCommentContent());
        comment.setCommentTime(new Date());
        commentService.addComment(comment);

        // 行为记录
        if (request.getUserId() != null) {
            userBehaviorService.recordBehavior(
                    request.getUserId(),
                    "travel_diary",
                    request.getDiaryId(),
                    UserBehavior.BehaviorType.comment
            );
        }

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        return result;
    }

    // 获取评论列表
    @GetMapping("/comments")
    public List<Comment> getComments(@RequestParam Long diaryId) {
        return commentService.getCommentsByDiaryId(diaryId);
    }
}