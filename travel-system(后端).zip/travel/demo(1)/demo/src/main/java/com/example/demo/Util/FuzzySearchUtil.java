package com.example.demo.Util;

public class FuzzySearchUtil {

    /**
     * 计算两个字符串的编辑距离（Levenshtein Distance）
     */
    public static int getDistance(String s1, String s2) {
        if (s1 == null || s2 == null) return Integer.MAX_VALUE;

        int len1 = s1.length();
        int len2 = s2.length();
        int[][] dp = new int[len1 + 1][len2 + 1];

        // 初始化
        for (int i = 0; i <= len1; i++) dp[i][0] = i;
        for (int j = 0; j <= len2; j++) dp[0][j] = j;

        // 动态规划填表
        for (int i = 1; i <= len1; i++) {
            char c1 = s1.charAt(i - 1);
            for (int j = 1; j <= len2; j++) {
                char c2 = s2.charAt(j - 1);

                if (c1 == c2) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.min(
                            Math.min(dp[i - 1][j] + 1,     // 删除
                                    dp[i][j - 1] + 1),    // 插入
                            dp[i - 1][j - 1] + 1           // 替换
                    );
                }
            }
        }

        return dp[len1][len2];
    }
}


