package com.example.demo.Controller;

import com.example.demo.common.ResponseMessage;
import com.example.demo.Dto.UserDto;
import com.example.demo.Dto.UserLoginDto;
import com.example.demo.Entity.user;
import com.example.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
public class UserController {
    @Autowired
    UserService userService;
    //增加
    @PostMapping
    public ResponseMessage add(@Validated @RequestBody UserDto user)
    {
        user userAdd =userService.add(user);
        return ResponseMessage.success(userAdd);
    }
    //login
    @PostMapping("/login")
    public ResponseMessage<Boolean> login(@RequestBody UserLoginDto userLoginDto) {
        boolean isLoginSuccessful = userService.login(userLoginDto.getId(), userLoginDto.getPassword());
        return ResponseMessage.success(isLoginSuccessful);
    }
}
