package com.example.demo.Service;

import com.example.demo.Entity.TravelDiary;
import java.util.List;
import java.util.List; // 导入 List
import java.util.Optional; // 导入 Optional
import org.springframework.data.domain.Sort; // 导入 Sort 类
public interface TravelDiaryService {
    TravelDiary addDiary(TravelDiary diary);

    List<TravelDiary> getDiariesByUserId(String userId);

    TravelDiary getDiaryById(Integer diaryId);

    TravelDiary updateDiary(TravelDiary diary);

    List<TravelDiary> searchDiariesByLocation(String location, String sortBy, String sortDirection);

    List<TravelDiary> searchDiaryByTitle(String title); // 修改返回类型为 List
    // 添加按内容进行全文检索的方法
    List<TravelDiary> searchDiariesByContent(String query);
}
