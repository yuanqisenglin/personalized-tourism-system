package com.example.demo.Entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "tb_rating")
public class Rating {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer ratingId;

    @Column(name = "diary_id")
    private Long diaryId;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "rating")
    private Integer rating;

    @Column(name = "rating_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date ratingTime;

    // getter 和 setter 省略，可用IDE自动生成
    public Integer getRatingId() {
        return ratingId;
    }
    public void setRatingId(Integer ratingId) {
        this.ratingId = ratingId;
    }
    public Long getDiaryId() {
        return diaryId;
    }
    public void setDiaryId(Long diaryId) {
        this.diaryId = diaryId;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public Integer getRating() {
        return rating;
    }
    public void setRating(Integer rating) {
        this.rating = rating;
    }
    public Date getRatingTime() {
        return ratingTime;
    }
    public void setRatingTime(Date ratingTime) {
        this.ratingTime = ratingTime;
    }
}