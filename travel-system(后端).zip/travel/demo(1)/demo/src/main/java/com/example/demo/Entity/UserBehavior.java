package com.example.demo.Entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tb_user_behavior")
public class UserBehavior {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long behaviorId;

    @Column(nullable = false, length = 11)
    private String userId;

    @Column(nullable = false, length = 45)
    private String targetType;

    @Column(nullable = false)
    private Long targetId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private BehaviorType behaviorType;

    @Column(nullable = false)
    private LocalDateTime behaviorTime;

    public enum BehaviorType {
        view, comment
    }

    public UserBehavior() {
        this.behaviorTime = LocalDateTime.now();
    }

    // getters and setters

    public Long getBehaviorId() {
        return behaviorId;
    }

    public void setBehaviorId(Long behaviorId) {
        this.behaviorId = behaviorId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public Long getTargetId() {
        return targetId;
    }

    public void setTargetId(Long targetId) {
        this.targetId = targetId;
    }

    public BehaviorType getBehaviorType() {
        return behaviorType;
    }

    public void setBehaviorType(BehaviorType behaviorType) {
        this.behaviorType = behaviorType;
    }

    public LocalDateTime getBehaviorTime() {
        return behaviorTime;
    }

    public void setBehaviorTime(LocalDateTime behaviorTime) {
        this.behaviorTime = behaviorTime;
    }
}
