package com.example.demo.Service;

import com.example.demo.Dto.UserDto;
import com.example.demo.Entity.user;

public interface UserService {
    user add(UserDto user);
    boolean login(String id, String password);
}
