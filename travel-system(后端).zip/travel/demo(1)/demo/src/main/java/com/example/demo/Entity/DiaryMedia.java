package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
@Table(name = "tb_diary_media")
public class DiaryMedia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "media_id")
    private Integer mediaId;

    @Column(name = "media_type", length = 20)
    private String mediaType;  // 比如 "图片" 或 "视频"

    @Column(name = "media_path", length = 255)
    private String mediaPath;

    // 多对一关系，多个媒体属于一个日记
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "diary_id")
    @JsonBackReference // 解决无限递归问题
    private TravelDiary travelDiary;

    // Getter 和 Setter

    public Integer getMediaId() {
        return mediaId;
    }

    public void setMediaId(Integer mediaId) {
        this.mediaId = mediaId;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public String getMediaPath() {
        return mediaPath;
    }

    public void setMediaPath(String mediaPath) {
        this.mediaPath = mediaPath;
    }

    public TravelDiary getTravelDiary() {
        return travelDiary;
    }

    public void setTravelDiary(TravelDiary travelDiary) {
        this.travelDiary = travelDiary;
    }

    @Override
    public String toString() {
        return "DiaryMedia{" +
                "mediaId=" + mediaId +
                ", mediaType='" + mediaType + '\'' +
                ", mediaPath='" + mediaPath + '\'' +
                '}';
    }
}
