package com.example.demo.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tb_user_interest_tag")
public class UserInterestTag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tag_relation_id")
    private Integer tagRelationId;

    @Column(name = "user_id", length = 11, nullable = false)
    private String userId;

    @Column(name = "interest_tag", length = 10, nullable = false)
    private String interestTag;

    // 构造函数
    public UserInterestTag() {}

    public UserInterestTag(String userId, String interestTag) {
        this.userId = userId;
        this.interestTag = interestTag;
    }
    // Getter 和 Setter
    public Integer getTagRelationId() {
        return tagRelationId;
    }
    public void setTagRelationId(Integer tagRelationId) {
        this.tagRelationId = tagRelationId;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getInterestTag() {
        return interestTag;
    }
    public void setInterestTag(String interestTag) {
        this.interestTag = interestTag;
    }
}