package com.example.demo.Controller;

import com.example.demo.Dto.FoodDTO;
import com.example.demo.Entity.Food;
import com.example.demo.Entity.UserBehavior;
import com.example.demo.Service.FoodService;
import com.example.demo.Service.UserBehaviorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/foods")
@CrossOrigin(origins = "http://localhost:8080")  // 根据你的前端地址设置
public class FoodController {

    private final FoodService foodService;
    private final UserBehaviorService userBehaviorService;

    @Autowired
    public FoodController(FoodService foodService, UserBehaviorService userBehaviorService) {
        this.foodService = foodService;
        this.userBehaviorService = userBehaviorService;
    }

    /**
     * 获取美食数据（支持筛选、模糊搜索和排序）
     * 示例请求：
     * /foods?type=主食&sortBy=rating&searchKeyword=麻辣
     */
    @GetMapping
    public List<FoodDTO>  getFoods(
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String searchKeyword,
            @RequestParam(required = false) String location
    ) {
        return foodService.getFoodData(type, sortBy, searchKeyword,location);
    }

    /**
     * 获取单个美食的详细信息
     * 示例请求：/foods/{id}?userId=123
     */
    @GetMapping("/{id}")
    public Food getFoodDetail(
            @PathVariable Long id,
            @RequestParam(required = false) String userId
    ) {
        Food food = foodService.getFoodById(id);
        if (food != null) {
            // 更新热度
            food.setPopularity(food.getPopularity() + 1);
            foodService.updateFood(food);

            // 如果提供了用户ID，记录浏览行为
            if (userId != null && !userId.isEmpty()) {
                userBehaviorService.recordBehavior(
                        userId,
                        "food",
                        id,
                        UserBehavior.BehaviorType.view
                );
            }
        }
        return food;
    }
}
