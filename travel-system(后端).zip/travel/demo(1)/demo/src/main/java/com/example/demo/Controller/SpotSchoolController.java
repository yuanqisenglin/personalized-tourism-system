package com.example.demo.Controller;

import com.example.demo.Entity.SpotSchool;
import com.example.demo.Entity.UserBehavior;
import com.example.demo.Service.SpotSchoolService;
import com.example.demo.Service.UserBehaviorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("/spotschools")
@CrossOrigin(origins = "http://localhost:8080")  // 前端的 URL
public class SpotSchoolController {
    private static final Logger logger = LoggerFactory.getLogger(SpotSchoolController.class);

    private final SpotSchoolService spotSchoolService;
    private final UserBehaviorService userBehaviorService;

    @Autowired
    public SpotSchoolController(SpotSchoolService spotSchoolService, UserBehaviorService userBehaviorService) {
        this.spotSchoolService = spotSchoolService;
        this.userBehaviorService = userBehaviorService;
    }

    /**
     * 获取 SpotSchool 数据（筛选、排序、搜索）
     * 示例请求：
     * /spotschools?type=spot&sortBy=rating&searchKeyword=公园
     */
    @GetMapping
    public List<SpotSchool> getSpotSchools(
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String searchKeyword
    ) {
        return spotSchoolService.getSpotSchoolData(type, sortBy, searchKeyword);
    }

    /**
     * 获取单个景点/学校的详细信息
     * 示例请求：/spotschools/{id}?userId=123
     */
    @GetMapping("/{id}")
    @Transactional
    public ResponseEntity<?> getSpotSchoolDetail(
            @PathVariable Long id,
            @RequestParam(required = false) String userId
    ) {
        try {
            logger.info("开始获取景点/学校详情，ID: {}, 用户ID: {}", id, userId);

            if (id == null) {
                logger.error("景点/学校ID不能为空");
                return ResponseEntity.badRequest().body("景点/学校ID不能为空");
            }

            SpotSchool spotSchool = spotSchoolService.getSpotSchoolById(id);
            if (spotSchool == null) {
                logger.warn("未找到ID为 {} 的景点/学校", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("未找到ID为 " + id + " 的景点/学校");
            }

            logger.info("找到景点/学校: {}, 当前热度: {}", spotSchool.getName(), spotSchool.getPopularity());

            // 更新热度
            try {
                spotSchool.setPopularity(spotSchool.getPopularity() + 1);
                spotSchool = spotSchoolService.updateSpotSchool(spotSchool);
                logger.info("更新热度成功，新热度: {}", spotSchool.getPopularity());
            } catch (Exception e) {
                logger.error("更新热度失败: {}", e.getMessage(), e);
                // 继续处理，不影响返回景点信息
            }

            // 如果提供了用户ID，记录浏览行为
            if (userId != null && !userId.isEmpty()) {
                try {
                    userBehaviorService.recordBehavior(
                        userId,
                        "spot_school",
                        id,
                        UserBehavior.BehaviorType.view
                    );
                    logger.info("记录用户行为成功，用户ID: {}", userId);
                } catch (Exception e) {
                    logger.error("记录用户行为失败: {}", e.getMessage(), e);
                    // 记录行为失败不影响返回景点信息
                }
            } else {
                logger.info("未提供用户ID，跳过记录用户行为");
            }

            return ResponseEntity.ok(spotSchool);
        } catch (Exception e) {
            logger.error("处理请求时发生错误: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("处理请求时发生错误: " + e.getMessage());
        }
    }
}