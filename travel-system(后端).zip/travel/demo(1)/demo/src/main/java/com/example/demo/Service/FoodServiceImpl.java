package com.example.demo.Service;

import com.example.demo.Dto.FoodDTO;
import com.example.demo.Entity.SpotSchool;
import com.example.demo.Repository.FoodRepository;
import com.example.demo.Entity.Food;
import com.example.demo.Util.FuzzySearchUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Repository.SpotSchoolRepository;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FoodServiceImpl implements FoodService {
    private  final SpotSchoolRepository spotSchoolRepository;
    private final FoodRepository foodRepository;
    @Autowired
    public FoodServiceImpl(FoodRepository foodRepository,
                           SpotSchoolRepository spotSchoolRepository) {
        this.foodRepository = foodRepository;
        this.spotSchoolRepository = spotSchoolRepository;
    }

    /**
     * 获取美食数据（筛选、排序、模糊搜索）
     */
    @Override
    public List<FoodDTO> getFoodData(String type, String sortBy, String searchKeyword, String location) {
        // 判断 location 类型
        String locationType = null;
        if (location != null && !location.trim().isEmpty()) {
            SpotSchool spotSchool = spotSchoolRepository.findByName(location);
            if (spotSchool != null) {
                locationType = spotSchool.getType(); // "spot" or "school"
            }
        }

        // 查询并排序
        List<Food> roughList = foodRepository.searchAndSortFoods(type, searchKeyword, sortBy);

        // 如果排序方式是 distance，才使用地点类型排序
        if ("distance".equals(sortBy) && locationType != null) {
            if ("景点".equals(locationType)) {
                roughList.sort(Comparator.comparing(Food::getDistanceToSpot));
            } else if ("校园".equals(locationType)) {
                roughList.sort(Comparator.comparing(Food::getDistanceToSchool));
            }
        }

        // 降级模糊搜索
        if ((roughList == null || roughList.isEmpty()) && searchKeyword != null && !searchKeyword.trim().isEmpty()) {
            List<Food> allFoods = foodRepository.findAll();
            roughList = allFoods.stream()
                    .sorted(Comparator.comparingInt(food -> {
                        int nameDist = FuzzySearchUtil.getDistance(food.getName(), searchKeyword);
                        int restDist = FuzzySearchUtil.getDistance(food.getRestaurantname(), searchKeyword);
                        int cuisineDist = FuzzySearchUtil.getDistance(food.getCuisine_type(), searchKeyword);
                        return Math.min(Math.min(nameDist, restDist), cuisineDist);
                    }))
                    .limit(10)
                    .collect(Collectors.toList());
        }

        // 转换为 FoodDTO，只保留一个 distance 字段
        String finalLocationType = locationType; // lambda 中需要 final 变量
        return roughList.stream()
                .map(food -> {
                    Double distance = null;
                    if ("景点".equals(finalLocationType)) {
                        distance = food.getDistanceToSpot();
                    } else if ("校园".equals(finalLocationType)) {
                        distance = food.getDistanceToSchool();
                    }
                    return new FoodDTO(
                            food.getId(),
                            food.getName(),
                            food.getCuisine_type(),
                            food.getPopularity(),
                            food.getRating(),
                            food.getRestaurantname(),
                            food.getType(),
                            distance
                    );
                })
                .collect(Collectors.toList());
    }



    @Override
    public Food getFoodById(Long id) {
        return foodRepository.findById(id).orElse(null);
    }

    // 更新美食信息
    @Override
    public Food updateFood(Food food) {
        return foodRepository.save(food);
    }

}
