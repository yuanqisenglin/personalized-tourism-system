package com.example.demo.Controller;

import com.example.demo.Entity.Rating;
import com.example.demo.Service.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/diary") // <-- 修改为 "/diary"
@CrossOrigin
public class RatingController {

    @Autowired
    private RatingService ratingService;

    // 添加评分
    @PostMapping("/rate")
    public Map<String, Object> rateDiary(@RequestParam Long diaryId,
                                         @RequestParam String userId,
                                         @RequestParam Integer rating) {
        Rating r = new Rating();
        r.setDiaryId(diaryId);
        r.setUserId(userId);
        r.setRating(rating);
        r.setRatingTime(new Date());
        ratingService.addRating(r);

        double avg = ratingService.getAverageRating(diaryId);

        // 查出该用户最新一次评分并返回
        List<Rating> userRatings = ratingService.getRatingsByDiaryIdAndUserId(diaryId, userId);
        int userRating = userRatings.isEmpty() ? 0 : userRatings.get(userRatings.size() - 1).getRating();

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("averageRating", avg);
        result.put("userRating", userRating); // 返回用户评分
        return result;
    }

    // 获取评分
    @GetMapping("/rating")
    public Map<String, Object> getDiaryRating(@RequestParam Long diaryId,
                                              @RequestParam String userId) {
        double avg = ratingService.getAverageRating(diaryId);
        List<Rating> userRatings = ratingService.getRatingsByDiaryIdAndUserId(diaryId, userId);
        int userRating = userRatings.isEmpty() ? 0 : userRatings.get(userRatings.size() - 1).getRating();

        Map<String, Object> result = new HashMap<>();
        result.put("averageRating", avg);
        result.put("userRating", userRating);
        return result;
    }
}