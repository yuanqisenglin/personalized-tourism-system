package com.example.demo.Repository;

import com.example.demo.Entity.user;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CrudRepository<user,String> {
    user findByIdAndPassword(String id, String password);
}
