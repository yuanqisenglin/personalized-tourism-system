package com.example.demo.Service;

import com.example.demo.Entity.Rating;
import java.util.List;

public interface RatingService {
    Rating addRating(Rating rating);
    List<Rating> getRatingsByDiaryId(Long diaryId);
    List<Rating> getRatingsByDiaryIdAndUserId(Long diaryId, String userId);
    double getAverageRating(Long diaryId);
}