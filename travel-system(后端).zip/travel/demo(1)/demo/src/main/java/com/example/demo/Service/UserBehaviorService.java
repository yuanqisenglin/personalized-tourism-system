package com.example.demo.Service;

import com.example.demo.Entity.UserBehavior;
import com.example.demo.Repository.UserBehaviorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.dao.DataAccessException;

import java.time.LocalDateTime;

@Service
public class UserBehaviorService {

    @Autowired
    private UserBehaviorRepository userBehaviorRepository;

    @Transactional
    public UserBehavior recordBehavior(String userId, String targetType, Long targetId, UserBehavior.BehaviorType behaviorType) {
        try {
            System.out.println("准备保存用户行为：userId=" + userId + ", targetType=" + targetType + ", targetId=" + targetId + ", behaviorType=" + behaviorType);

            if (userId == null || userId.trim().isEmpty()) {
                throw new IllegalArgumentException("用户ID不能为空");
            }

            UserBehavior behavior = new UserBehavior();
            behavior.setUserId(userId);
            behavior.setTargetType(targetType);
            behavior.setTargetId(targetId);
            behavior.setBehaviorType(behaviorType);
            behavior.setBehaviorTime(LocalDateTime.now());

            UserBehavior saved = userBehaviorRepository.save(behavior);
            System.out.println("保存用户行为成功：" + saved);
            return saved;

        } catch (DataAccessException e) {
            System.err.println("数据库操作失败：" + e.getMessage());
            throw new RuntimeException("保存用户行为记录失败", e);
        } catch (Exception e) {
            System.err.println("保存用户行为时发生错误：" + e.getMessage());
            throw new RuntimeException("保存用户行为记录时发生未知错误", e);
        }
    }
}