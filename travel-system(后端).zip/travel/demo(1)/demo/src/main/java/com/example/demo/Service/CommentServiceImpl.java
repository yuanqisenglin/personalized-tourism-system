package com.example.demo.Service;

import com.example.demo.Entity.Comment;
import com.example.demo.Repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {
    @Autowired
    private CommentRepository commentRepository;

    @Override
    public Comment addComment(Comment comment) {
        return commentRepository.save(comment);
    }

    @Override
    public List<Comment> getCommentsByDiaryId(Long diaryId) {
        return commentRepository.findByDiaryIdOrderByCommentTimeAsc(diaryId);
    }
}