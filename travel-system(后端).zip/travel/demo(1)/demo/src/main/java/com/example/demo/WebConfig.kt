package com.example.demo;
import com.example.demo.interceptor.XContentTypeOptionsInterceptor
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.web.servlet.config.annotation.CorsRegistry
import org.springframework.web.servlet.config.annotation.InterceptorRegistry
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import java.nio.file.Paths // 导入 Paths

@Configuration
open class WebConfig {

    // 注入配置的文件上传根目录
    @Value("\${app.upload-dir}")
    private var baseUploadDir: String? = null

    // 定义一个 WebMvcConfigurer Bean 来配置 CORS, 静态资源和拦截器
    @Bean
    open fun customWebMvcConfigurer(): WebMvcConfigurer {
        return object : WebMvcConfigurer {
            // CORS 配置
            override fun addCorsMappings(registry: CorsRegistry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:8080") // 将 * 修改为明确的前端地址
                        .allowedMethods("GET", "POST", "PUT", "DELETE")
                        .allowedHeaders("*")
                        .allowCredentials(true)
            }

            // 静态资源映射
            override fun addResourceHandlers(registry: ResourceHandlerRegistry) {
                println("--- Attempting to configure static resource handler for /uploads/ ---") // 新增日志
                println("Value of app.upload-dir (injected): $baseUploadDir") // 新增日志

                // 检查注入的值是否为空或空字符串
                if (baseUploadDir.isNullOrEmpty()) {
                    println("Warning: 'app.upload-dir' is not configured or empty. Static resource mapping for /uploads/** will not be active.")
                    println("--- Finished configuring static resource handler ---") // 新增日志
                    return // 如果没有配置路径，则不注册资源处理器
                }

                try {
                    // 使用 Paths.get 构建文件系统路径，并转换为绝对路径字符串
                    val baseDir = requireNotNull(baseUploadDir) { "'app.upload-dir' must not be null" }
                    val uploadDirectory = Paths.get(baseDir, "uploads").toAbsolutePath().toString()

                    // 构建 file:// URL
                    val fileLocation = "file:///" + uploadDirectory.replace("\\", "/") + "/"

                    println("Injected baseUploadDir: $baseUploadDir") // 调整日志内容
                    println("Constructed upload directory path: $uploadDirectory") // 调整日志内容
                    println("Constructed file:// URL for resource mapping: $fileLocation") // 调整日志内容

                    // 将 /uploads/** 的请求映射到实际的文件系统目录
                    registry.addResourceHandler("/uploads/**")
                            .addResourceLocations(fileLocation)

                    println("--- Successfully configured static resource handler for /uploads/ ---") // 新增日志

                } catch (e: Exception) {
                    println("Error configuring resource handler for /uploads/**: ${e.message}")
                    e.printStackTrace()
                    println("--- Failed to configure static resource handler ---") // 新增日志
                }
            }

            // 拦截器
            override fun addInterceptors(registry: InterceptorRegistry) {
                // 如果你需要 XContentTypeOptionsInterceptor 拦截器，保留这里
                // registry.addInterceptor(XContentTypeOptionsInterceptor()).addPathPatterns("/**")
            }
        }
    }

    // 如果有其他非 WebMvcConfigurer 相关的 Bean，可以在这里继续定义
}