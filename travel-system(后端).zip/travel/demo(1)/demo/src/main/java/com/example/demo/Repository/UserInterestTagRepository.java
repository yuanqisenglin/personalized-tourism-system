package com.example.demo.Repository;

import com.example.demo.Entity.UserInterestTag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

import jakarta.transaction.Transactional;

public interface UserInterestTagRepository extends JpaRepository<UserInterestTag, Integer> {

    List<UserInterestTag> findByUserId(String userId);

    @Modifying
    @Transactional
    @Query("DELETE FROM UserInterestTag u WHERE u.userId = ?1 AND u.interestTag = ?2")
    void deleteByUserId(String userId, String interestTag);
}
