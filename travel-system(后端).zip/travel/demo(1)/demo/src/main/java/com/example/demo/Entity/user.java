package com.example.demo.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_user")
public class user {

    @Id  // 标明主键
    @Column(name = "user_id", unique = true)  // 映射数据库中的 user_id 列，并确保唯一
    private String id;

    @Column(name = "username", unique = true)  // 映射数据库中的 username 列，并确保唯一
    private String username;

    @Column(name = "password")  // 映射数据库中的 password 列
    private String password;

    // Getter 和 Setter 方法
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "user{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
