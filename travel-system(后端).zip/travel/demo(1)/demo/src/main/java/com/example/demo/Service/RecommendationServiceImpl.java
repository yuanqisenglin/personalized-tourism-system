package com.example.demo.Service;

import com.example.demo.Entity.*;
import com.example.demo.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class RecommendationServiceImpl implements RecommendationService {

    private static final Logger logger = LoggerFactory.getLogger(RecommendationServiceImpl.class);

    @Autowired
    private UserBehaviorRepository userBehaviorRepository;

    @Autowired
    private SpotSchoolRepository spotSchoolRepository;

    @Autowired
    private FoodRepository foodRepository;

    @Autowired
    private TravelDiaryRepository travelDiaryRepository;

    @Autowired
    private UserInterestTagRepository userInterestTagRepository;

    @Override
    public List<SpotSchool> getRecommendedSpots(String userId, int limit) {
        Map<String, Integer> userInterests = getUserInterests(userId);
        List<Object[]> mostViewedTypes = userBehaviorRepository.findMostViewedContentTypes(userId);
        Map<String, Double> typeWeights = calculateTypeWeights(mostViewedTypes);

        return spotSchoolRepository.findAll().stream()
                .filter(spot -> spot.getType().equals("景点"))
                .sorted((a, b) -> {
                    double scoreA = calculateSpotScore(a, userInterests, typeWeights, userId);
                    double scoreB = calculateSpotScore(b, userInterests, typeWeights, userId);
                    return Double.compare(scoreB, scoreA);
                })
                .limit(limit)
                .collect(Collectors.toList());
    }

    @Override
    public List<SpotSchool> getRecommendedSchools(String userId, int limit) {
        Map<String, Integer> userInterests = getUserInterests(userId);
        List<Object[]> mostViewedTypes = userBehaviorRepository.findMostViewedContentTypes(userId);
        Map<String, Double> typeWeights = calculateTypeWeights(mostViewedTypes);

        return spotSchoolRepository.findAll().stream()
                .filter(school -> school.getType().equals("校园"))
                .sorted((a, b) -> {
                    double scoreA = calculateSchoolScore(a, userInterests, typeWeights, userId);
                    double scoreB = calculateSchoolScore(b, userInterests, typeWeights, userId);
                    return Double.compare(scoreB, scoreA);
                })
                .limit(limit)
                .collect(Collectors.toList());
    }

    @Override
    public List<Food> getRecommendedFoods(String userId, int limit) {
        Map<String, Integer> userInterests = getUserInterests(userId);
        List<Object[]> mostViewedTypes = userBehaviorRepository.findMostViewedContentTypes(userId);
        Map<String, Double> typeWeights = calculateTypeWeights(mostViewedTypes);

        return foodRepository.findAll().stream()
                .sorted((a, b) -> {
                    double scoreA = calculateFoodScore(a, userInterests, typeWeights, userId);
                    double scoreB = calculateFoodScore(b, userInterests, typeWeights, userId);
                    return Double.compare(scoreB, scoreA);
                })
                .limit(limit)
                .collect(Collectors.toList());
    }

    @Override
    public List<TravelDiary> getRecommendedDiaries(String userId, int limit) {
        Map<String, Integer> userInterests = getUserInterests(userId);
        List<Object[]> mostViewedTypes = userBehaviorRepository.findMostViewedContentTypes(userId);
        Map<String, Double> typeWeights = calculateTypeWeights(mostViewedTypes);

        return travelDiaryRepository.findAll().stream()
                .sorted((a, b) -> {
                    double scoreA = calculateDiaryScore(a, userInterests, typeWeights, userId);
                    double scoreB = calculateDiaryScore(b, userInterests, typeWeights, userId);
                    return Double.compare(scoreB, scoreA);
                })
                .limit(limit)
                .collect(Collectors.toList());
    }

    @Override
    public Map<String, Integer> getUserInterests(String userId) {
        logger.info("开始获取用户[{}]的兴趣标签和权重", userId);

        // 1. 获取用户显式设置的兴趣标签
        List<UserInterestTag> userTags = userInterestTagRepository.findByUserId(userId);
        logger.info("从数据库获取到用户显式设置的标签: {}", userTags);

        Map<String, Integer> interestCounts = new HashMap<>();

        // 将用户显式设置的兴趣标签添加到计数中，给予较高权重
        // 修改：对重复标签进行去重，只保留一个，但给予更高权重
        Set<String> uniqueTags = new HashSet<>();
        for (UserInterestTag tag : userTags) {
            uniqueTags.add(tag.getInterestTag());
        }

        for (String tag : uniqueTags) {
            // 计算该标签的出现次数
            long tagCount = userTags.stream()
                    .filter(t -> t.getInterestTag().equals(tag))
                    .count();
            // 基础权重20，每重复一次增加10点权重，但最多不超过50
            int weight = Math.min(20 + (int)(tagCount - 1) * 10, 50);
            interestCounts.merge(tag, weight, Integer::sum);
            logger.info("添加显式标签[{}]，权重: {}，出现次数: {}",
                    tag, weight, tagCount);
        }

        // 2. 获取用户行为数据
        LocalDateTime thirtyDaysAgo = LocalDateTime.now().minus(30, ChronoUnit.DAYS);
        List<UserBehavior> recentBehaviors = userBehaviorRepository.findByUserIdAndBehaviorTimeBetween(
                userId, thirtyDaysAgo, LocalDateTime.now()
        );
        logger.info("获取到用户最近30天的行为记录数: {}", recentBehaviors.size());

        // 3. 从用户行为中提取兴趣
        List<UserBehavior> allBehaviors = userBehaviorRepository.findByUserId(userId);
        logger.info("获取到用户所有行为记录数: {}", allBehaviors.size());

        for (UserBehavior behavior : allBehaviors) {
            String targetType = behavior.getTargetType();
            int weight = (behavior.getBehaviorType() == UserBehavior.BehaviorType.comment ? 2 : 1)
                    * (recentBehaviors.contains(behavior) ? 2 : 1);
            logger.debug("处理行为记录: type={}, behaviorType={}, weight={}",
                    targetType, behavior.getBehaviorType(), weight);

            if (targetType.equals("spot") || targetType.equals("school")) {
                spotSchoolRepository.findById(behavior.getTargetId()).ifPresent(content -> {
                    logger.debug("从景点/学校提取关键词: name={}, description={}",
                            content.getName(), content.getDescription());
                    extractKeywords(content.getName(), weight, interestCounts);
                    extractKeywords(content.getDescription(), weight, interestCounts);
                });
            } else if (targetType.equals("food")) {
                foodRepository.findById(behavior.getTargetId()).ifPresent(food -> {
                    logger.debug("从美食提取关键词: cuisineType={}", food.getCuisine_type());
                    extractKeywords(food.getCuisine_type(), weight, interestCounts);
                });
            } else if (targetType.equals("travel_diary")) {
                travelDiaryRepository.findById(behavior.getTargetId().intValue()).ifPresent(diary -> {
                    logger.debug("从旅游日记提取关键词: title={}, content={}",
                            diary.getTitle(), diary.getContent());
                    extractKeywords(diary.getTitle(), weight, interestCounts);
                    extractKeywords(diary.getContent(), weight, interestCounts);
                });
            }
        }

        // 4. 返回兴趣标签和权重 Map (不再限制数量和排序，由调用者处理)
        logger.info("最终获取到的用户兴趣标签和权重: {}", interestCounts);
        return interestCounts;
    }

    private void extractKeywords(String text, int weight, Map<String, Integer> interestCounts) {
        if (text != null) {
            // 1. 预处理：将常见的菜系名称标准化
            text = normalizeCuisineType(text);

            // 2. 使用更智能的分词方法，保留完整的菜系名称
            String[] words = text.split("[^a-zA-Z0-9\\u4e00-\\u9fa5]+");
            Set<String> stopWords = new HashSet<>(Arrays.asList(
                    "的", "了", "和", "是", "在", "我", "有", "这", "那", "就", "都", "也", "很", "到", "说", "要", "去", "你", "会", "着", "没有", "看", "好", "自己", "这",
                    "菜", "饭", "面", "汤", "肉", "鱼", "鸡", "鸭", "鹅", "虾", "蟹", "蛋", "豆腐" // 添加常见食材作为停用词
            ));

            // 3. 特殊处理：保留完整的菜系名称
            Set<String> cuisineTypes = new HashSet<>(Arrays.asList(
                    "粤菜", "川菜", "湘菜", "鲁菜", "苏菜", "浙菜", "闽菜", "徽菜", "京菜", "沪菜",
                    "粤式", "川式", "湘式", "鲁式", "苏式", "浙式", "闽式", "徽式", "京式", "沪式",
                    "广东菜", "四川菜", "湖南菜", "山东菜", "江苏菜", "浙江菜", "福建菜", "安徽菜", "北京菜", "上海菜"
            ));

            // 4. 先检查是否包含完整的菜系名称
            for (String cuisine : cuisineTypes) {
                if (text.contains(cuisine)) {
                    interestCounts.merge(cuisine, weight * 2, Integer::sum); // 菜系名称给予双倍权重
                    logger.debug("发现菜系名称[{}]，权重: {}", cuisine, weight * 2);
                }
            }

            // 5. 处理其他关键词
            for (String word : words) {
                if (word.length() > 1 && !stopWords.contains(word) && !cuisineTypes.contains(word)) {
                    double tf = weight;
                    double idf = Math.log(1000.0 / (1 + getKeywordFrequency(word)));
                    int finalWeight = (int) (tf * idf);

                    interestCounts.merge(word, finalWeight, Integer::sum);
                    logger.debug("关键词[{}]权重更新: TF={}, IDF={}, 最终权重={}",
                            word, tf, idf, finalWeight);
                }
            }
        }
    }

    private String normalizeCuisineType(String text) {
        if (text == null) return "";

        // 标准化菜系名称
        Map<String, String> cuisineMap = new HashMap<>();
        cuisineMap.put("粤式", "粤菜");
        cuisineMap.put("广东菜", "粤菜");
        cuisineMap.put("川式", "川菜");
        cuisineMap.put("四川菜", "川菜");
        cuisineMap.put("湘式", "湘菜");
        cuisineMap.put("湖南菜", "湘菜");
        // ... 可以添加更多映射

        String normalized = text;
        for (Map.Entry<String, String> entry : cuisineMap.entrySet()) {
            normalized = normalized.replace(entry.getKey(), entry.getValue());
        }
        return normalized;
    }

    private int getKeywordFrequency(String keyword) {
        // 这里应该实现一个缓存机制，避免频繁查询数据库
        // 简化实现，实际应该从数据库或缓存中获取
        return 1;
    }

    private Map<String, Double> calculateTypeWeights(List<Object[]> mostViewedTypes) {
        Map<String, Double> weights = new HashMap<>();
        if (mostViewedTypes != null && !mostViewedTypes.isEmpty()) {
            long totalViews = mostViewedTypes.stream().mapToLong(arr -> (Long) arr[1]).sum();
            for (Object[] typeCount : mostViewedTypes) {
                String type = (String) typeCount[0];
                long count = (Long) typeCount[1];
                weights.put(type, (double) count / totalViews);
            }
        }
        return weights;
    }

    private double calculateCosineSimilarity(Map<String, Integer> userInterests, Map<String, Integer> contentKeywords) {
        double dotProduct = 0.0;
        double normUser = 0.0;
        double normContent = 0.0;

        // 计算点积和范数
        for (Map.Entry<String, Integer> entry : userInterests.entrySet()) {
            String keyword = entry.getKey();
            int userWeight = entry.getValue();
            int contentWeight = contentKeywords.getOrDefault(keyword, 0);

            dotProduct += userWeight * contentWeight;
            normUser += userWeight * userWeight;
        }

        for (int weight : contentKeywords.values()) {
            normContent += weight * weight;
        }

        // 避免除以零
        if (normUser == 0 || normContent == 0) {
            return 0.0;
        }

        return dotProduct / (Math.sqrt(normUser) * Math.sqrt(normContent));
    }

    private double calculateTimeDecayFactor(LocalDateTime contentTime) {
        long daysDiff = ChronoUnit.DAYS.between(contentTime, LocalDateTime.now());
        return Math.exp(-0.1 * daysDiff); // 使用指数衰减
    }

    private double calculateSpotScore(SpotSchool spot, Map<String, Integer> interestsWithWeights, Map<String, Double> typeWeights, String userId) {
        logger.info("开始计算景点[{}]的推荐分数", spot.getName());

        // 1. 基础热度分数 (降低权重)
        double score = spot.getPopularity() * 0.05;
        logger.debug("基础热度分数: {} * 0.05 = {}", spot.getPopularity(), score);

        // 2. 相似度分数 (提高权重)
        Map<String, Integer> spotKeywords = new HashMap<>();
        extractKeywords(spot.getName(), 1, spotKeywords);
        extractKeywords(spot.getDescription(), 1, spotKeywords);
        double similarityScore = calculateCosineSimilarity(interestsWithWeights, spotKeywords) * 0.7; // 提高相似度权重
        score += similarityScore;
        logger.debug("相似度分数: {}", similarityScore);

        // 3. 用户互动分数
        long interactions = userBehaviorRepository.countUserInteractions(userId, spot.getId());
        double interactionScore = Math.log1p(interactions) * 0.25; // 略微提高互动分数权重
        score += interactionScore;
        logger.debug("用户互动分数: log(1 + {}) * 0.25 = {}", interactions, interactionScore);

        // 4. 类型权重调整
        double typeWeight = typeWeights.getOrDefault("spot", 0.0);
        score *= (1.0 + typeWeight * 0.5);
        logger.debug("类型权重调整: * (1.0 + {} * 0.5)", typeWeight);

        logger.info("景点[{}]最终推荐分数: {}", spot.getName(), score);
        return score;
    }

    private double calculateSchoolScore(SpotSchool school, Map<String, Integer> interestsWithWeights, Map<String, Double> typeWeights, String userId) {
        logger.info("开始计算学校[{}]的推荐分数", school.getName());

        // 修改点：热度权值从 0.3 改为 0.1
        double score = school.getPopularity() * 0.1;
        logger.debug("基础热度分数: {} * 0.1 = {}", school.getPopularity(), score);

        double keywordScore = matchKeywordsScore(school.getName(), school.getDescription(), interestsWithWeights);
        score += keywordScore;
        logger.debug("关键词匹配分数: {}", keywordScore);

        long interactions = userBehaviorRepository.countUserInteractions(userId, school.getId());
        double interactionScore = interactions * 5.0;
        score += interactionScore;
        logger.debug("用户互动分数: {} * 5.0 = {}", interactions, interactionScore);

        double typeWeight = typeWeights.getOrDefault("school", 0.0);
        score *= (1.0 + typeWeight);
        logger.debug("类型权重调整: * (1.0 + {})", typeWeight);

        logger.info("学校[{}]最终推荐分数: {}", school.getName(), score);
        return score;
    }

    private double calculateFoodScore(Food food, Map<String, Integer> interestsWithWeights, Map<String, Double> typeWeights, String userId) {
        logger.info("开始计算美食[{}]的推荐分数", food.getName());

        // 1. 基础热度分数（降低权重）
        double score = food.getPopularity() * 0.03;
        logger.debug("基础热度分数: {} * 0.03 = {}", food.getPopularity(), score);

        // 2. 相似度分数
        Map<String, Integer> foodKeywords = new HashMap<>();

        // 2.1 处理菜系类型（给予更高权重）
        if (food.getCuisine_type() != null) {
            String normalizedCuisineType = normalizeCuisineType(food.getCuisine_type());
            extractKeywords(normalizedCuisineType, 5, foodKeywords); // 进一步提高菜系类型权重
            logger.debug("处理菜系类型[{}]，标准化后[{}]", food.getCuisine_type(), normalizedCuisineType);
        }

        // 2.2 处理美食名称
        extractKeywords(food.getName(), 2, foodKeywords); // 提高美食名称权重

        // 2.3 计算相似度分数
        double similarityScore = calculateCosineSimilarity(interestsWithWeights, foodKeywords) * 0.9; // 进一步提高相似度权重
        score += similarityScore;
        logger.debug("相似度分数: {}", similarityScore);

        // 3. 用户互动分数（降低权重）
        long interactions = userBehaviorRepository.countUserInteractions(userId, food.getId());
        double interactionScore = Math.log1p(interactions) * 0.1; // 进一步降低互动分数权重
        score += interactionScore;
        logger.debug("用户互动分数: log(1 + {}) * 0.1 = {}", interactions, interactionScore);

        // 4. 类型权重调整
        double typeWeight = typeWeights.getOrDefault("food", 0.0);
        score *= (1.0 + typeWeight * 0.3); // 降低类型权重的影响
        logger.debug("类型权重调整: * (1.0 + {} * 0.3)", typeWeight);

        // 5. 评分加成
        if (food.getRating() >= 4.0) {
            score *= 1.2; // 高评分美食获得20%的加成
            logger.debug("高评分加成: * 1.2 (评分: {})", food.getRating());
        }

        logger.info("美食[{}]最终推荐分数: {}", food.getName(), score);
        return score;
    }

    private double calculateDiaryScore(TravelDiary diary, Map<String, Integer> interestsWithWeights, Map<String, Double> typeWeights, String userId) {
        logger.info("开始计算旅游日记[{}]的推荐分数", diary.getTitle());

        // 修改点：热度权值从 0.3 改为 0.1
        double score = diary.getPopularity() * 0.1;
        logger.debug("基础热度分数: {} * 0.1 = {}", diary.getPopularity(), score);
        // ↓↓↓ 新增评分加成逻辑，加在基础热度之后 ↓↓↓
        // 假设 TravelDiary 实体类有 getRating() 方法，返回 BigDecimal 类型
        if (diary.getRating() != null) {
            double rating = diary.getRating().doubleValue(); // 显式转换为 double
            if (rating >= 4.0) {
                score *= 1.2;
                logger.debug("高评分加成: * 1.2 (评分: {})", rating);
            } else if (rating >= 3.0) {
                score *= 1.1;
                logger.debug("中等评分加成: * 1.1 (评分: {})", rating);
            }
        }
        double keywordScore = matchKeywordsScore(diary.getTitle(), diary.getContent(), interestsWithWeights);
        score += keywordScore;
        logger.debug("关键词匹配分数: {}", keywordScore);

        long interactions = userBehaviorRepository.countUserInteractions(userId, diary.getDiaryId().longValue());
        double interactionScore = interactions * 5.0;
        score += interactionScore;
        logger.debug("用户互动分数: {} * 5.0 = {}", interactions, interactionScore);

        double typeWeight = typeWeights.getOrDefault("travel_diary", 0.0);
        score *= (1.0 + typeWeight);
        logger.debug("类型权重调整: * (1.0 + {})", typeWeight);

        logger.info("旅游日记[{}]最终推荐分数: {}", diary.getTitle(), score);
        return score;
    }

    private double matchKeywordsScore(String name, String description, Map<String, Integer> interestsWithWeights) {
        double score = 0.0;
        String fullText = (name != null ? name : "") + " " + (description != null ? description : "");
        logger.debug("开始匹配文本: name={}, description={}", name, description);
        logger.debug("用户兴趣标签和权重: {}", interestsWithWeights);

        for (Map.Entry<String, Integer> entry : interestsWithWeights.entrySet()) {
            String interest = entry.getKey();
            Integer weight = entry.getValue();

            if (fullText.contains(interest)) {
                // 根据权重调整加分
                double matchBaseScore = 5.0 * weight / 20.0;
                score += matchBaseScore;
                logger.debug("兴趣标签[{}]匹配成功，基础分+{} (权重{})",
                        interest, matchBaseScore, weight);

                if (name != null && name.contains(interest)) {
                    double nameMatchScore = 3.0 * weight / 20.0;
                    score += nameMatchScore;
                    logger.debug("兴趣标签[{}]在名称中匹配成功，额外+{} (权重{})",
                            interest, nameMatchScore, weight);
                }
            } else {
                logger.debug("兴趣标签[{}]未匹配", interest);
            }
        }

        logger.debug("最终匹配得分: {}", score);
        return score;
    }
}