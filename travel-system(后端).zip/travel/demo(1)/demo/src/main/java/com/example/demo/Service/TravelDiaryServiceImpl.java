package com.example.demo.Service;
import java.util.List; // 导入 List
import com.example.demo.Entity.TravelDiary;
import com.example.demo.Repository.TravelDiaryRepository;
import com.example.demo.Util.CompressionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional; // 导入 Optional
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Sort; // 导入 Sort 类
import java.util.ArrayList; // 导入 ArrayList, 用于返回空列表


@Service
public class TravelDiaryServiceImpl implements TravelDiaryService {

    @Autowired
    private TravelDiaryRepository diaryRepository;

    @Override
    public TravelDiary addDiary(TravelDiary diary) {
        diary.setCreateTime(new Date());
        diary.setPopularity(0);
        diary.setRating(BigDecimal.ZERO);

        // 压缩正文内容并保存到 contentCompressed
        if (diary.getContent() != null) {
            try {
                byte[] compressed = CompressionUtil.compress(diary.getContent());
                // 调试打印
                System.out.println("原始内容长度: " + diary.getContent().length());
                System.out.println("压缩后字节长度: " + compressed.length);

                diary.setContentCompressed(compressed);
                // 同时将未压缩的原始内容保存到 contentUncompressedForSearch
                diary.setContentUncompressedForSearch(diary.getContent());
            } catch (IOException e) {
                // 处理压缩或保存错误，抛出运行时异常
                throw new RuntimeException("处理正文内容失败", e);
            }
        } else {
            // 如果内容为null，也确保contentCompressed和contentUncompressedForSearch为null
            diary.setContentCompressed(null);
            diary.setContentUncompressedForSearch(null);
        }

        return diaryRepository.save(diary);
    }

    @Override
    public TravelDiary updateDiary(TravelDiary diary) {
        // 假设传入的diary对象已经包含了更新后的content字段 (未压缩内容)
        // 在这里，您需要根据更新后的 content 字段，重新处理 contentCompressed 和 contentUncompressedForSearch

        // 注意：在实际更新场景中，通常需要先从数据库加载现有日记，然后合并更新的内容
        // 这里为了演示处理内容字段，假设传入的 diary 对象是完整的更新数据
        // 如果您的实际更新逻辑更复杂，请根据实际情况调整这里的处理

        if (diary.getContent() != null) {
            try {
                byte[] compressed = CompressionUtil.compress(diary.getContent());
                diary.setContentCompressed(compressed);
                // 同步更新未压缩内容字段
                diary.setContentUncompressedForSearch(diary.getContent());
            } catch (IOException e) {
                throw new RuntimeException("处理更新的正文内容失败", e);
            }
        } else {
            // 如果更新后的内容为null
            diary.setContentCompressed(null);
            diary.setContentUncompressedForSearch(null);
        }
        return diaryRepository.save(diary); // save 方法用于更新
    }


    @Override
    public List<TravelDiary> getDiariesByUserId(String userId) {
        // 使用新的去重查询
        return diaryRepository.findDistinctByUserId(userId);
    }

    @Override
    public TravelDiary getDiaryById(Integer diaryId) {
        TravelDiary diary = diaryRepository.findWithMediaByDiaryIdDistinct(diaryId).orElse(null);
        // 在返回前解压内容，以便 Controller 或前端可以使用 content 字段
        if (diary != null && diary.getContentCompressed() != null) {
            try {
                diary.setContent(CompressionUtil.decompress(diary.getContentCompressed()));
            } catch (IOException e) {
                // 打印错误或进行其他处理，但不中断方法的返回
                System.err.println("解压日记内容失败 (ID: " + diary.getDiaryId() + "): " + e.getMessage());
                // 可以选择设置 content 为 null 或错误信息
                diary.setContent("[内容解压失败]");
            }
        }
        return diary;
    }

    @Override
    public List<TravelDiary> searchDiariesByLocation(String location, String sortBy, String sortDirection) {
        // 构建 Sort 对象
        Sort sort = Sort.by(Sort.Direction.fromString(sortDirection), sortBy);

        // 调用 Repository 方法进行查询和排序
        List<TravelDiary> diaries = diaryRepository.findByLocation(location, sort);

        // 在返回前解压内容（如果需要在搜索结果中显示）
        for (TravelDiary diary : diaries) {
            if (diary.getContentCompressed() != null) {
                try {
                    diary.setContent(CompressionUtil.decompress(diary.getContentCompressed()));
                } catch (IOException e) {
                    System.err.println("解压日记内容失败 (ID: " + diary.getDiaryId() + "): " + e.getMessage());
                    diary.setContent("[内容解压失败]");
                }
            }
        }

        return diaries;
    }

    @Override
    public List<TravelDiary> searchDiaryByTitle(String title) {
        List<TravelDiary> diaries = diaryRepository.findByTitle(title); // 调用返回 List 的 Repository 方法

        // 遍历列表，解压内容
        for (TravelDiary diary : diaries) {
            if (diary.getContentCompressed() != null) {
                try {
                    diary.setContent(CompressionUtil.decompress(diary.getContentCompressed()));
                } catch (IOException e) {
                    System.err.println("解压日记内容失败 (ID: " + diary.getDiaryId() + "): " + e.getMessage());
                    diary.setContent("[内容解压失败]");
                }
            }
        }

        return diaries; // 返回列表
    }

    @Override
    public List<TravelDiary> searchDiariesByContent(String query) {
        // 检查查询关键词是否为空或只有空白字符
        if (query == null || query.trim().isEmpty()) {
            // 如果关键词为空，返回空列表或者根据业务需求返回默认结果（例如热门日记）
            return new ArrayList<>(); // 返回一个新的空列表
        }

        // 调用 Repository 方法执行全文检索
        List<TravelDiary> diaries = diaryRepository.findByContentMatch(query);

        // 在返回前解压内容（如果需要在搜索结果中显示）
        // 遍历列表，解压内容
        for (TravelDiary diary : diaries) {
            // 注意：这里的解压是可选的，取决于前端是否需要在搜索结果列表显示解压后的内容
            // 如果只在详情页显示，这里可以跳过解压，节省性能开销
            if (diary.getContentCompressed() != null) {
                try {
                    diary.setContent(CompressionUtil.decompress(diary.getContentCompressed()));
                } catch (IOException e) {
                    System.err.println("解压日记内容失败 (ID: " + diary.getDiaryId() + "): " + e.getMessage());
                    diary.setContent("[内容解压失败]");
                }
            }
        }

        return diaries; // 返回实际结果列表
    }
}