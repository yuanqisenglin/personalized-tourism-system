package com.example.demo.Controller;
import com.example.demo.Service.UserBehaviorService;
import com.example.demo.Dto.TravelDiaryDTO;
import com.example.demo.Entity.DiaryMedia;
import com.example.demo.Entity.TravelDiary;
import com.example.demo.Entity.UserBehavior;

import com.example.demo.Service.TravelDiaryService;
import com.example.demo.Util.ImageCompressionUtil;
import net.coobird.thumbnailator.Thumbnails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.Optional;
import java.util.List; // 导入 List
import java.util.List; // 导入 List
import java.util.Map; // 导入 Map
import java.util.HashMap; // 导入 HashMap
import org.springframework.web.bind.annotation.RequestParam; // 导入 RequestParam
@RestController
@RequestMapping("/diary")
@CrossOrigin
public class TravelDiaryController {
    @Autowired
    private UserBehaviorService userBehaviorService;

    @Autowired
    private TravelDiaryService diaryService;

    @Value("${app.upload-dir}")
    private String baseUploadDir;

    @PostMapping("/uploadMedia")
    @CrossOrigin
    public Map<String, Object> uploadMedia(@RequestParam("file") MultipartFile[] files) {
        Map<String, Object> result = new HashMap<>();
        List<String> urls = new ArrayList<>();

        if (files == null || files.length == 0) {
            result.put("success", false);
            result.put("message", "文件为空");
            return result;
        }

        try {
            Path uploadPath = Paths.get(baseUploadDir, "uploads");
            File dir = uploadPath.toFile();
            if (!dir.exists()) {
                dir.mkdirs();
            }

            for (MultipartFile file : files) {
                String originalFilename = file.getOriginalFilename();
                String suffix = originalFilename.substring(originalFilename.lastIndexOf('.') + 1).toLowerCase();
                String fileName = UUID.randomUUID().toString() + "_" + originalFilename;
                Path destPath = uploadPath.resolve(fileName);
                File destFile = destPath.toFile();

                // 先保存上传的原始文件到临时文件
                File tempOriginalFile = uploadPath.resolve("temp_" + fileName).toFile();
                file.transferTo(tempOriginalFile);

                if (isImage(suffix)) {
                    // 压缩图片，传入File
                    compressImage(tempOriginalFile, destFile);
                } else if (isVideo(suffix)) {
                    // 压缩视频
                    compressVideoWithFFmpeg(tempOriginalFile, destFile);
                } else {
                    // 其他文件直接复制
                    Files.copy(tempOriginalFile.toPath(), destPath);
                }

                // 调用工具类验证压缩是否成功，打印大小信息
                if (isImage(suffix) || isVideo(suffix)) {
                    ImageCompressionUtil.verifyCompression(tempOriginalFile.getAbsolutePath(), destFile.getAbsolutePath());
                }

                // 删除临时文件
                tempOriginalFile.delete();

                String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/uploads/")
                        .path(fileName)
                        .toUriString();
                urls.add(fileUrl);
            }

            result.put("success", true);
            result.put("urls", urls);
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "上传失败：" + e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    // 添加按地点查询并排序的API
    @GetMapping("/searchByLocation")
    public List<TravelDiary> searchByLocation(
            @RequestParam String location, // 目的地参数
            @RequestParam(defaultValue = "popularity") String sortBy, // 排序字段，默认为 popularity
            @RequestParam(defaultValue = "desc") String sortDirection) { // 排序方向，默认为降序

        // 调用 Service 层方法
        return diaryService.searchDiariesByLocation(location, sortBy, sortDirection);
    }
    @PostMapping("/add")
    public Map<String, Object> addDiary(@RequestBody TravelDiaryDTO dto) {
        Map<String, Object> response = new HashMap<>();
        try {
            TravelDiary diary = new TravelDiary();
            diary.setTitle(dto.getTitle());
            diary.setContent(dto.getContent());
            diary.setUserId(dto.getUserId());
            diary.setLocation(dto.getLocation());
            diary.setCreateTime(new Date());
            diary.setPopularity(0);
            diary.setRating(BigDecimal.ZERO);

            List<DiaryMedia> mediaList = dto.getMediaList().stream().map(mediaDTO -> {
                DiaryMedia media = new DiaryMedia();
                media.setMediaPath(mediaDTO.getUrl());
                media.setMediaType(mediaDTO.getType());
                media.setTravelDiary(diary);
                return media;
            }).collect(Collectors.toList());

            diary.setMediaList(mediaList);

            TravelDiary saved = diaryService.addDiary(diary);
            response.put("success", true);
            response.put("id", saved.getDiaryId());
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            e.printStackTrace();
        }
        return response;
    }
    @GetMapping("/searchByTitle")
    public List<TravelDiary> searchByTitle(@RequestParam String title) { // 修改返回类型为 List
        return diaryService.searchDiaryByTitle(title);
    }
    // 添加按内容进行全文检索的API
    @GetMapping("/searchByContent")
    public List<TravelDiary> searchByContent(@RequestParam String query) {
        return diaryService.searchDiariesByContent(query);
    }
    @GetMapping("/user/{userId}")
    public List<TravelDiary> getUserDiaries(@PathVariable String userId) {
        return diaryService.getDiariesByUserId(userId);
    }

    @GetMapping("/{id}")
    public TravelDiary getDiaryDetail(@PathVariable Integer id, @RequestParam(required = false) String userId) {
        TravelDiary diary = diaryService.getDiaryById(id);
        if (diary != null) {
            // 热度 +1
            diary.setPopularity(diary.getPopularity() + 1);
            diaryService.updateDiary(diary); // 这一行目前没实现！

            // 记录一次 view 行为（如果提供了 userId）
            if (userId != null && !userId.isEmpty()) {
                userBehaviorService.recordBehavior(
                        userId,
                        "travel_diary",
                        id.longValue(),
                        UserBehavior.BehaviorType.view
                );
            }
        }
        return diary;
    }

    // 判断是否图片格式
    private boolean isImage(String suffix) {
        return Arrays.asList("jpg", "jpeg", "png", "gif", "bmp", "webp").contains(suffix.toLowerCase());
    }

    // 判断是否视频格式
    private boolean isVideo(String suffix) {
        return Arrays.asList("mp4", "avi", "mov", "wmv", "flv", "mkv").contains(suffix.toLowerCase());
    }

    // 图片压缩，使用 Thumbnailator
    private void compressImage(File srcFile, File destFile) throws IOException {
        // 例：压缩到宽高不超过1024，保持比例
        Thumbnails.of(srcFile)
                .size(1024, 1024)
                .outputQuality(0.8) // 压缩质量80%
                .toFile(destFile);
    }

    // 视频压缩（示例调用FFmpeg命令）
    private void compressVideoWithFFmpeg(File srcFile, File destFile) throws IOException, InterruptedException {
        List<String> command = Arrays.asList(
                "ffmpeg",
                "-i", srcFile.getAbsolutePath(),
                "-vf", "scale=-2:720",
                "-b:v", "1000k",
                "-y",
                destFile.getAbsolutePath()
        );

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true); // 合并标准输出和错误输出
        Process process = pb.start();

        // 读取并打印 FFmpeg 输出日志（避免阻塞）
        try (Scanner scanner = new Scanner(process.getInputStream())) {
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IOException("FFmpeg 视频压缩失败，退出码：" + exitCode);
        }
    }

}
