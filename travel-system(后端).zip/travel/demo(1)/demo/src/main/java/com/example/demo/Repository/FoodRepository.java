package com.example.demo.Repository;

import com.example.demo.Entity.Food;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodRepository extends JpaRepository<Food, Long> {

    @Query("SELECT s FROM Food s " +
            "WHERE (:type IS NULL OR s.cuisine_type = :type) " +
            "AND (" +
            "   :searchKeyword IS NULL OR " +
            "   LOWER(s.name) LIKE LOWER(CONCAT('%', :searchKeyword, '%')) OR " +
            "   LOWER(s.cuisine_type) LIKE LOWER(CONCAT('%', :searchKeyword, '%')) OR " +
            "   LOWER(s.restaurantname) LIKE LOWER(CONCAT('%', :searchKeyword, '%'))" +
            ") " +
            "ORDER BY " +
            "CASE WHEN :sortBy = 'popularity' THEN s.popularity END DESC, " +
            "CASE WHEN :sortBy = 'rating' THEN s.rating END DESC")
    List<Food> searchAndSortFoods(
            @Param("type") String type,
            @Param("searchKeyword") String searchKeyword,
            @Param("sortBy") String sortBy
    );

}
