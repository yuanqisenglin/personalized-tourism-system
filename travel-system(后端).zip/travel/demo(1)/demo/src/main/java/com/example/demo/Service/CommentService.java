package com.example.demo.Service;

import com.example.demo.Entity.Comment;
import java.util.List;

public interface CommentService {
    Comment addComment(Comment comment);
    List<Comment> getCommentsByDiaryId(Long diaryId);
}