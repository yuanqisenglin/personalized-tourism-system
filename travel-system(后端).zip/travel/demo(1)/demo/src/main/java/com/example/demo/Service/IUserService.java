package com.example.demo.Service;
import com.example.demo.Repository.UserRepository;
import com.example.demo.Dto.UserDto;
import com.example.demo.Entity.user;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IUserService implements UserService{
    @Autowired
    UserRepository userRepository;
    @Override
    public user add(UserDto user) {
        user userPojo=new user();
        BeanUtils.copyProperties(user,userPojo);
        userRepository.save(userPojo);
        return userPojo;
    }
    @Override
    public boolean login(String id, String password) {
        user user = userRepository.findByIdAndPassword(id, password);
        return user != null;
    }
}
