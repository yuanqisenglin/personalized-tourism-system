package com.example.demo.Service;

import com.example.demo.Entity.Food;
import com.example.demo.Entity.SpotSchool;
import com.example.demo.Entity.TravelDiary;
import java.util.List;
import java.util.Map;

public interface RecommendationService {
    // 获取基于用户兴趣的景点推荐
    List<SpotSchool> getRecommendedSpots(String userId, int limit);

    // 获取基于用户兴趣的学校推荐
    List<SpotSchool> getRecommendedSchools(String userId, int limit);

    // 获取基于用户兴趣的美食推荐
    List<Food> getRecommendedFoods(String userId, int limit);

    // 获取基于用户兴趣的旅游日记推荐
    List<TravelDiary> getRecommendedDiaries(String userId, int limit);

    // 获取用户的兴趣标签
    Map<String, Integer> getUserInterests(String userId);
}