package com.example.demo.Controller;

import com.example.demo.Dto.UserBehaviorDto;
import com.example.demo.Entity.UserBehavior;
import com.example.demo.Service.UserBehaviorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/behavior")
public class UserBehaviorController {

    @Autowired
    private UserBehaviorService userBehaviorService;

    @PostMapping("/record")
    public ResponseEntity<?> recordUserBehavior(@RequestBody UserBehaviorDto dto) {
        UserBehavior.BehaviorType type;
        try {
            type = UserBehavior.BehaviorType.valueOf(dto.getBehaviorType());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Invalid behaviorType. Must be one of [view, comment,]");
        }

        UserBehavior behavior = userBehaviorService.recordBehavior(
                dto.getUserId(),
                dto.getTargetType(),
                dto.getTargetId(),
                type
        );

        return ResponseEntity.ok(behavior);
    }
}
