package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "tb_travel_diary")
public class TravelDiary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "diary_id")
    private Integer diaryId;

    @Column(name = "user_id", length = 11)
    private String userId;

    @Column(name = "title", length = 200)
    private String title;
    @Column(name = "location", length = 255) // 添加这一行，定义地点字段及其映射列名和长度
    private String location; // 添加这一行，定义地点属性
    @Lob
    @Column(name = "content_compressed", columnDefinition = "LONGBLOB")
    private byte[] contentCompressed;
    // 新增用于全文搜索的未压缩内容字段
    @Lob // LOB 表示大对象，适合存储长文本
    @Column(name = "content_uncompressed_for_search", columnDefinition = "LONGTEXT") // 映射到新增的数据库列
    private String contentUncompressedForSearch; // 使用 String 类型存储未压缩文本
    @Transient
    private String content;  // 解压后内容，非数据库字段

    @Column(name = "popularity")
    private int popularity;

    @Column(name = "rating", precision = 2, scale = 1)
    private BigDecimal rating;

    @Column(name = "create_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    @OneToMany(mappedBy = "travelDiary", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<DiaryMedia> mediaList;

    // Getter 和 Setter
    public Integer getDiaryId() {
        return diaryId;
    }

    public void setDiaryId(Integer diaryId) {
        this.diaryId = diaryId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public byte[] getContentCompressed() {
        return contentCompressed;
    }

    public void setContentCompressed(byte[] contentCompressed) {
        this.contentCompressed = contentCompressed;
    }
    // 新增字段的 Getter 和 Setter
    public String getContentUncompressedForSearch() {
        return contentUncompressedForSearch;
    }

    public void setContentUncompressedForSearch(String contentUncompressedForSearch) {
        this.contentUncompressedForSearch = contentUncompressedForSearch;
    }
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    public int getPopularity() {
        return popularity;
    }

    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    public BigDecimal getRating() {
        return rating;
    }

    public void setRating(BigDecimal rating) {
        this.rating = rating;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public List<DiaryMedia> getMediaList() {
        return mediaList;
    }

    public void setMediaList(List<DiaryMedia> mediaList) {
        this.mediaList = mediaList;
    }

    public TravelDiary() {
        // 无参构造
    }

    @Override
    public String toString() {
        return "TravelDiary{" +
                "diaryId=" + diaryId +
                ", userId='" + userId + '\'' +
                ", title='" + title + '\'' +
                ", location='" + location + '\'' +
                // 注意：这里不打印 contentCompressed 和 contentUncompressedForSearch，避免日志过长
                ", popularity=" + popularity +
                ", rating=" + rating +
                ", createTime=" + createTime +
                ", mediaList size=" + (mediaList != null ? mediaList.size() : 0) + // 打印列表大小而不是整个列表
                '}';
    }
}
