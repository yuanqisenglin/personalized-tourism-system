package com.example.demo.Controller;

import com.example.demo.Entity.UserInterestTag;
import com.example.demo.Repository.UserInterestTagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/interests")
public class UserInterestTagController {

    @Autowired
    private UserInterestTagRepository userInterestTagRepository;

    // 添加兴趣标签
    // 添加兴趣标签
    @PostMapping("/add")
    public UserInterestTag addInterestTag(@RequestBody UserInterestTag tag) {
        System.out.println("接收到的标签对象: " + tag.getUserId() + ", " + tag.getInterestTag());
        return userInterestTagRepository.save(tag);
    }

    // 查询某个用户的兴趣标签
    @GetMapping("/user/{userId}")
    public List<UserInterestTag> getTagsByUserId(@PathVariable String userId) {
        System.out.println("接收到的用户ID: " + userId);  // 添加日志，查看是否收到请求
        return userInterestTagRepository.findByUserId(userId);
    }

    // 删除某个用户的所有标签
    @DeleteMapping("/user/{userId}/tag/{interestTag}")
    public void deleteTagByUserIdAndInterestTag(@PathVariable String userId, @PathVariable String interestTag) {
        System.out.println("删除标签请求：用户ID = " + userId + ", 标签 = " + interestTag);
        userInterestTagRepository.deleteByUserId(userId, interestTag);

    }
}