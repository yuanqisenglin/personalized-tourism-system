package com.example.demo.Repository;

import com.example.demo.Entity.TravelDiary;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Sort; // 导入 Sort 类

import java.util.List;
import java.util.Optional;

public interface TravelDiaryRepository extends JpaRepository<TravelDiary, Integer> {

    // 查询某用户日记，带媒体，去重
    @EntityGraph(attributePaths = {"mediaList"})
    @Query("select distinct d from TravelDiary d left join fetch d.mediaList where d.userId = ?1")
    List<TravelDiary> findDistinctByUserId(String userId);

    // 查询单篇日记，带媒体，去重
    @EntityGraph(attributePaths = {"mediaList"})
    @Query("select distinct d from TravelDiary d left join fetch d.mediaList where d.diaryId = ?1")
    Optional<TravelDiary> findWithMediaByDiaryIdDistinct(Integer diaryId);
    // 根据地点查询日记，并支持排序
    // 使用 @EntityGraph 确保媒体列表也被一同加载，避免 N+1 问题
    @EntityGraph(attributePaths = {"mediaList"})
    List<TravelDiary> findByLocation(String location, Sort sort);
    // 根据标题精确查找日记
    // 根据标题精确查找日记，返回列表以处理可能存在的同名日记
    List<TravelDiary> findByTitle(String title); // 修改返回类型为 List

    // 添加按内容进行全文检索的方法
    // 使用 @Query 执行原生 SQL，利用 MySQL 的 MATCH AGAINST
    // :query 是一个命名参数，对应方法参数 String query
    // IN NATURAL LANGUAGE MODE 表示自然语言模式搜索
    // 注意：这里使用了您之前选择的未压缩内容列名 content_uncompressed_for_search
    @Query(value = "SELECT td.* FROM tb_travel_diary td WHERE MATCH(td.content_uncompressed_for_search) AGAINST(?1 IN NATURAL LANGUAGE MODE)", nativeQuery = true)
    List<TravelDiary> findByContentMatch(String query);
    // 如果需要相关性排序，可以在 AGAINST 后面加上 WITH QUERY EXPANSION 或 IN BOOLEAN MODE，并在 ORDER BY 中使用相关性分数
    // 例如：ORDER BY MATCH(td.content_uncompressed_for_search) AGAINST(?1 IN NATURAL LANGUAGE MODE) DESC
}