package com.example.demo.Service;

import com.example.demo.Entity.SpotSchool;
import com.example.demo.Repository.SpotSchoolRepository;
import com.example.demo.Util.FuzzySearchUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SpotSchoolService {

    private final SpotSchoolRepository spotSchoolRepository;

    @Autowired
    public SpotSchoolService(SpotSchoolRepository spotSchoolRepository) {
        this.spotSchoolRepository = spotSchoolRepository;
    }

    public List<SpotSchool> getSpotSchoolData(String type, String sortBy, String searchKeyword) {
        // 排序规则
        Sort sort;
        if ("rating".equals(sortBy)) {
            sort = Sort.by(Sort.Direction.DESC, "rating");
        } else if ("popularity".equals(sortBy)) {
            sort = Sort.by(Sort.Direction.DESC, "popularity");
        } else {
            sort = Sort.by(Sort.Direction.ASC, "id");  // 默认
        }
        System.out.println(">>> 模糊匹配关键词：" + searchKeyword);
        // 先查询
        List<SpotSchool> resultList = spotSchoolRepository.findByCriteria(type, searchKeyword, sort);

        // 若结果为空且 searchKeyword 不为空，兜底执行 Java 模糊搜索
        if ((resultList == null || resultList.isEmpty()) && searchKeyword != null && !searchKeyword.trim().isEmpty()) {
            System.out.println(">>> 进入兜底模糊匹配逻辑 <<<");

            List<SpotSchool> allList = spotSchoolRepository.findAll();
            int maxDistance = 5;

            return allList.stream()
                    .filter(s -> type == null || s.getType().equalsIgnoreCase(type))
                    .map(s -> {
                        int nameDist = FuzzySearchUtil.getDistance(s.getName(), searchKeyword);
                        int descDist = FuzzySearchUtil.getDistance(s.getDescription(), searchKeyword);
                        int minDist = Math.min(nameDist, descDist);
                        System.out.println("候选项：" + s.getName() + "，距离：" + minDist);
                        return new java.util.AbstractMap.SimpleEntry<>(s, minDist);
                    })
                    .filter(entry -> entry.getValue() <= maxDistance)
                    .sorted(Comparator.comparingInt(java.util.Map.Entry::getValue))
                    .limit(10)
                    .map(java.util.Map.Entry::getKey)
                    .collect(Collectors.toList());
        }

        System.out.println("type = " + type);
        System.out.println("sortBy = " + sortBy);
        System.out.println("searchKeyword = " + searchKeyword);
        System.out.println("数据库初步结果数量 = " + resultList.size());

        return resultList;
    }
    // 获取单个景点/学校信息
    public SpotSchool getSpotSchoolById(Long id) {
        return spotSchoolRepository.findById(id).orElse(null);
    }

    // 更新景点/学校信息
    public SpotSchool updateSpotSchool(SpotSchool spotSchool) {
        return spotSchoolRepository.save(spotSchool);
    }
}