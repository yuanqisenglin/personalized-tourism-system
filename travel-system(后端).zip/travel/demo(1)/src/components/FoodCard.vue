<template>
  <div class="food-card">
    <h3>
      <span class="top-rank">{{ rank }}</span> {{ food.name }}
    </h3>
    <p>菜系: {{ food.cuisine_type }}</p>
    <p>饭店: {{ food.restaurantname }}</p>
    <p>热度: {{ food.popularity }}</p>
    <p>评价: {{ food.rating }}</p>
    <p>距离: {{ food.distance }} km</p>
  </div>
</template>

<script setup>
// 添加注释忽略 ESLint 的 "no-undef" 报错
// eslint-disable-next-line no-undef
const props = defineProps({
  food: {
    type: Object,
    required: true,
  },
  rank: {
    type: Number,
    required: true,
  },
});

// 移除 emit 定义
// const emit = defineEmits(['view-detail']);

// 移除 viewFoodDetail 方法
/*
const viewFoodDetail = (foodId) => {
  emit('view-detail', foodId);
};
*/
</script>

<style scoped>
.food-card {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 10px;
  margin-bottom: 10px;
  /* 移除光标样式和hover效果 */
  /* cursor: pointer; */
  /* transition: transform 0.2s ease; */
}

/* 移除hover效果 */
/*
.food-card:hover {
  transform: translateY(-5px);
}
*/

.top-rank {
  background-color: #ffc107;
  color: white;
  padding: 5px 8px;
  border-radius: 4px;
  margin-right: 10px;
  font-weight: bold;
  display: inline-block;
}
</style> 