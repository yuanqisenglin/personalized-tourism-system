<template>
  <div class="attraction-card">
    <h3>
      <span class="top-rank">{{ rank }}</span> {{ attraction.name }}
    </h3>
    <p>类型: {{ attraction.type === 'spot' ? '景点' : '学校' }}</p>
    <p>热度: {{ attraction.popularity }}</p>
    <p>评分: {{ attraction.rating }}</p>
    <p>{{ attraction.description }}</p>
  </div>
</template>

<script setup>
defineProps({
  attraction: {
    type: Object,
    required: true
  },
  rank: {
    type: Number,
    required: true
  }
});
</script>

<style scoped>
.attraction-card {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 10px;
  margin-bottom: 10px;
  background-color: white;
}

.top-rank {
  background-color: #ffc107;
  color: white;
  padding: 5px 8px;
  border-radius: 4px;
  margin-right: 10px;
  font-weight: bold;
  display: inline-block;
}

h3 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 1.1em;
}

p {
  margin: 5px 0;
  color: #666;
  font-size: 0.9em;
  line-height: 1.4;
}
</style> 