<template>
  <div>
    <FoodSearchBar
      v-model:locationQuery="locationQuery"
      v-model:searchQuery="searchQuery"
      v-model:cuisineFilter="cuisineFilter"
      v-model:sortBy="sortBy"
      @search="fetchFoods"
    />
    <div class="recommendation-area">
      <FoodCard
        v-for="(food, index) in foods.slice(0, 10)"
        :key="food.id"
        :food="food"
        :rank="index + 1"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted } from "vue";
import axios from "axios";
import FoodSearchBar from "../components/FoodSearchBar.vue";
import FoodCard from "../components/FoodCard.vue";

// 搜索条件
const locationQuery = ref("");
const searchQuery = ref("");
const cuisineFilter = ref("");
const sortBy = ref(""); // 排序方式，如 'popularity' 或 'rating'
// 返回的美食数据
const foods = ref([]);

// 请求后端获取美食数据
const fetchFoods = async () => {
  try {
    const response = await axios.get("http://localhost:9090/foods", {
      params: {
        type: cuisineFilter.value || null,
        searchKeyword: searchQuery.value || null,
        sortBy: sortBy.value || null, // 添加对 sortBy 的处理
      },
    });

    // 映射字段
    foods.value = response.data.map((item) => ({
      ...item,
      cuisine: item.cuisine_type,
      restaurant: item.restaurantname,
    }));

    // *** 在获取并显示数据后，为前10个美食记录浏览行为并更新热度 ***
    const userId = localStorage.getItem('userId'); // 从本地存储获取用户ID
    if (userId) { // 只有当用户ID存在时才记录行为
      // 遍历显示的前10个美食
      for (let i = 0; i < Math.min(foods.value.length, 10); i++) {
        const food = foods.value[i];
        try {
          // 调用后端获取单个美食详情的接口，后端会处理热度更新和行为记录
          // 这里使用 await 确保顺序执行，避免短时间内对同一美食发送过多请求
          await axios.get(`http://localhost:9090/foods/${food.id}`, {
            params: {
              userId: userId
            }
          });
          console.log(`用户 ${userId} 浏览了美食 ${food.id}，热度已更新`);
        } catch (error) {
          console.error(`记录美食 ${food.id} 浏览行为失败：`, error);
        }
      }
       // 可选：所有热度更新和行为记录完成后，重新获取美食列表以更新显示的热度
       // 放在循环外部可以减少请求次数
       // fetchFoods(); // 移除此行，避免无限循环
    } else {
       console.warn("用户ID未找到，无法记录浏览行为");
    }

  } catch (error) {
    console.error("获取美食数据失败：", error);
  }
};

// 初始化加载
onMounted(fetchFoods);

// 当搜索条件变化时重新请求
watch([searchQuery, cuisineFilter, sortBy], fetchFoods, { immediate: true }); // 添加 immediate: true，组件加载时立即触发 watch

// 当 FoodSearchBar 触发 search 事件时重新请求（如果需要）
// 这里 FoodSearchBar 的 v-model 已经监听了输入变化，通常不需要额外的 search 事件
// 如果 FoodSearchBar 有一个明确的搜索按钮，则可以启用以下 watch
/*
watch(() => props.searchTrigger, () => {
  fetchFoods();
});
*/
</script>

<style scoped>
.recommendation-area {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 10px;
  padding: 10px;
}
</style> 