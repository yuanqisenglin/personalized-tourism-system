<template>
  <div class="recommendation-page">
    <h1 class="page-title">为您推荐</h1>
    
    <!-- 用户兴趣标签展示 -->
    <div class="interests-section" v-if="userInterests.length > 0">
      <h2>您的兴趣标签</h2>
      <div class="interest-tags">
        <span v-for="interest in userInterests" :key="interest" class="interest-tag">
          {{ interest }}
        </span>
      </div>
    </div>

    <!-- 分类切换按钮 -->
    <div class="category-buttons">
      <button 
        :class="{ active: selectedCategory === 'spots' }" 
        @click="selectCategory('spots')"
      >
        景点
      </button>
      <button 
        :class="{ active: selectedCategory === 'schools' }" 
        @click="selectCategory('schools')"
      >
        学校
      </button>
      <button 
        :class="{ active: selectedCategory === 'foods' }" 
        @click="selectCategory('foods')"
      >
        美食
      </button>
      <button 
        :class="{ active: selectedCategory === 'diaries' }" 
        @click="selectCategory('diaries')"
      >
        旅游日记
      </button>
    </div>
    
    <!-- 推荐内容区域，根据选中分类显示 -->
    <div v-if="selectedCategory === 'spots'">
      <section class="recommendation-section">
        <h2>景点推荐</h2>
        <div class="recommendation-grid">
          <AttractionCard
            v-for="spot in recommendedSpots"
            :key="spot.id"
            :attraction="spot"
          />
        </div>
      </section>
    </div>

    <div v-else-if="selectedCategory === 'schools'">
      <section class="recommendation-section">
        <h2>学校推荐</h2>
        <div class="recommendation-grid">
          <AttractionCard
            v-for="school in recommendedSchools"
            :key="school.id"
            :attraction="school"
          />
        </div>
      </section>
    </div>

    <div v-else-if="selectedCategory === 'foods'">
      <section class="recommendation-section">
        <h2>美食推荐</h2>
        <div class="recommendation-grid">
          <FoodCard
            v-for="food in recommendedFoods"
            :key="food.id"
            :food="food"
          />
        </div>
      </section>
    </div>

    <div v-else-if="selectedCategory === 'diaries'">
      <section class="recommendation-section">
        <h2>旅游日记推荐</h2>
        <div class="recommendation-grid">
          <TravelDiaryCard
            v-for="diary in recommendedDiaries"
            :key="diary.diaryId"
            :diary="diary"
          />
        </div>
      </section>
    </div>
    
    <div v-else>
      <p class="select-category-message">请选择一个分类查看推荐</p>
    </div>

  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import axios from 'axios';
import AttractionCard from '../components/AttractionCard.vue';
import FoodCard from '../components/FoodCard.vue';
// 假设您有一个 TravelDiaryCard 组件用于展示日记
import TravelDiaryCard from '../components/TravelDiaryCard.vue';

const userId = ref(localStorage.getItem('userId'));
const userInterests = ref([]);
const recommendedSpots = ref([]);
const recommendedSchools = ref([]);
const recommendedFoods = ref([]);
const recommendedDiaries = ref([]);

// 新增：当前选中的分类
const selectedCategory = ref(null); // 初始不选中任何分类

// 获取用户兴趣标签 (页面加载时获取一次)
const fetchUserInterests = async () => {
  if (!userId.value) {
    userInterests.value = [];
    return;
  }
  try {
    // 注意：后端接口路径已修改为 /recommendations 而不是 /api/recommendations
    const response = await axios.get(`/recommendations/interests/${userId.value}`);
    userInterests.value = response.data || [];
  } catch (error) {
    console.error('获取用户兴趣失败：', error);
    userInterests.value = [];
  }
};

// 获取特定分类的推荐内容
const fetchCategoryRecommendations = async (category) => {
  if (!userId.value) {
    console.warn('用户未登录，无法获取个性化推荐');
    // 清空所有推荐列表
    recommendedSpots.value = [];
    recommendedSchools.value = [];
    recommendedFoods.value = [];
    recommendedDiaries.value = [];
    selectedCategory.value = null; // 重置选中分类
    return;
  }

  // 先清空所有列表，避免显示旧数据
  recommendedSpots.value = [];
  recommendedSchools.value = [];
  recommendedFoods.value = [];
  recommendedDiaries.value = [];
  
  let endpoint = '';
  switch (category) {
    case 'spots':
      endpoint = `/recommendations/spots/${userId.value}`;
      break;
    case 'schools':
      endpoint = `/recommendations/schools/${userId.value}`;
      break;
    case 'foods':
      endpoint = `/recommendations/foods/${userId.value}`;
      break;
    case 'diaries':
      endpoint = `/recommendations/diaries/${userId.value}`;
      break;
    default:
      console.warn('未知分类:', category);
      selectedCategory.value = null; // 未知分类则不显示任何内容
      return;
  }

  try {
    const response = await axios.get(endpoint);
    const data = response.data;
    
    // 根据分类将数据赋值给对应的推荐列表
    switch (category) {
      case 'spots':
        recommendedSpots.value = data || [];
        break;
      case 'schools':
        recommendedSchools.value = data || [];
        break;
      case 'foods':
        recommendedFoods.value = data || [];
        break;
      case 'diaries':
        recommendedDiaries.value = data || [];
        break;
    }
    selectedCategory.value = category; // 更新选中的分类
    
  } catch (error) {
    console.error(`获取 ${category} 推荐失败：`, error);
    // 发生错误时也清空当前分类的数据
    switch (category) {
      case 'spots':
        recommendedSpots.value = [];
        break;
      case 'schools':
        recommendedSchools.value = [];
        break;
      case 'foods':
        recommendedFoods.value = [];
        break;
      case 'diaries':
        recommendedDiaries.value = [];
        break;
    }
    selectedCategory.value = null; // 出错也重置选中分类
  }
};

// 按钮点击事件，选择分类并获取推荐
const selectCategory = (category) => {
  if (selectedCategory.value !== category) { // 如果选择的是不同的分类才重新加载
    selectedCategory.value = category; // 先更新选中状态
    fetchCategoryRecommendations(category);
  }
};

// 组件挂载时，只获取用户兴趣标签，不立即加载推荐内容
onMounted(() => {
  fetchUserInterests();
  // fetchCategoryRecommendations(selectedCategory.value); // 不在 mounted 时自动加载
});

// 监听用户ID变化，重新获取用户兴趣标签
watch(userId, (newUserId) => {
  fetchUserInterests();
  if (!newUserId) {
     // 用户退出登录时清空所有推荐和选中状态
     recommendedSpots.value = [];
     recommendedSchools.value = [];
     recommendedFoods.value = [];
     recommendedDiaries.value = [];
     selectedCategory.value = null;
  }
});

</script>

<style scoped>
.recommendation-page {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.page-title {
  font-size: 2em;
  color: #333;
  margin-bottom: 30px;
  text-align: center;
}

.interests-section {
  margin-bottom: 40px;
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 8px;
}

.interests-section h2 {
  font-size: 1.5em;
  color: #333;
  margin-bottom: 15px;
}

.interest-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.interest-tag {
  padding: 6px 12px;
  background-color: #e0e0e0;
  border-radius: 20px;
  font-size: 0.9em;
  color: #666;
}

.category-buttons {
  text-align: center;
  margin-bottom: 30px;
}

.category-buttons button {
  padding: 10px 20px;
  margin: 0 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #fff;
  cursor: pointer;
  font-size: 1em;
  transition: all 0.3s ease;
}

.category-buttons button.active {
  background-color: #1890ff;
  color: white;
  border-color: #1890ff;
}

.category-buttons button:hover:not(.active) {
  background-color: #f0f0f0;
}

.recommendation-section {
  margin-bottom: 40px;
}

.recommendation-section h2 {
  font-size: 1.5em;
  color: #333;
  margin-bottom: 20px;
  padding-bottom: 10px;
  border-bottom: 2px solid #eee;
}

.recommendation-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  padding: 10px;
}

.select-category-message {
  text-align: center;
  font-size: 1.2em;
  color: #666;
  padding: 50px;
}

@media (max-width: 768px) {
  .recommendation-grid {
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  }
  
  .page-title {
    font-size: 1.5em;
  }
  
  .recommendation-section h2 {
    font-size: 1.2em;
  }
  
  .category-buttons button {
      margin: 5px;
  }
}
</style> 