<script setup>
import TourismSearchBar from "../components/TourismSearchBar.vue";
import AttractionCard from "../components/AttractionCard.vue";
import { ref, computed, watch, onMounted } from "vue";
import { useRoute } from "vue-router";
import axios from "axios";

const route = useRoute();
const selectedCategory = ref(route.query.type || "景点");
const sortBy = ref(route.query.sortBy || "rating");
const searchKeyword = ref(route.query.searchKeyword || "");

const attractions = ref([]);
const isLoading = ref(false);
const error = ref(null);

// 获取数据方法
const fetchAttractions = async () => {
  isLoading.value = true;
  error.value = null;
  
  try {
    const response = await axios.get("/api/spotschools", {
      params: {
        type: selectedCategory.value,
        sortBy: sortBy.value,
        searchKeyword: searchKeyword.value,
      },
    });
    
    attractions.value = response.data;
    console.log("景点/学校数据获取成功：", attractions.value);

    // 记录用户浏览行为
    await recordUserBehaviors();
    
  } catch (error) {
    console.error("获取景点/学校数据失败：", error);
    error.value = "获取数据失败，请稍后重试";
  } finally {
    isLoading.value = false;
  }
};

// 记录用户浏览行为的方法
const recordUserBehaviors = async () => {
  const userId = localStorage.getItem("userId");
  if (!userId) {
    console.warn("用户未登录，无法记录浏览行为");
    return;
  }

  // 只处理前10个景点/学校
  const topAttractions = attractions.value.slice(0, 10);
  
  // 使用 Promise.all 并行处理所有请求，但限制并发数
  const batchSize = 3; // 每批处理3个请求
  for (let i = 0; i < topAttractions.length; i += batchSize) {
    const batch = topAttractions.slice(i, i + batchSize);
    await Promise.all(
      batch.map(async (attraction) => {
        try {
          await axios.get(`/api/spotschools/${attraction.id}`, {
            params: { userId }
          });
          console.log(`用户 ${userId} 浏览了${attraction.type === 'spot' ? '景点' : '学校'}：${attraction.name}`);
        } catch (error) {
          console.error(`记录${attraction.name}的浏览行为失败：`, error);
        }
      })
    );
    
    // 每批请求之间添加小延迟，避免服务器压力过大
    if (i + batchSize < topAttractions.length) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
};

// 初始化时获取数据
onMounted(fetchAttractions);

// 监听 URL 参数变化并重新获取数据
watch(
  () => route.query,
  () => {
    selectedCategory.value = route.query.type || "景点";
    sortBy.value = route.query.sortBy || "rating";
    searchKeyword.value = route.query.searchKeyword || "";
    fetchAttractions();
  },
  { immediate: true }
);

// 计算筛选后的数据
const filteredAttractions = computed(() => {
  if (!searchKeyword.value) {
    return attractions.value;
  }
  return attractions.value.filter((attraction) =>
    attraction.name.toLowerCase().includes(searchKeyword.value.toLowerCase())
  );
});
</script>

<template>
  <div>
    <TourismSearchBar />
    <div v-if="isLoading" class="loading">加载中...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <div v-else class="recommendation-area">
      <AttractionCard
        v-for="(attraction, index) in filteredAttractions.slice(0, 10)"
        :key="attraction.id"
        :attraction="attraction"
        :rank="index + 1"
      />
    </div>
  </div>
</template>

<style scoped>
.recommendation-area {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 10px;
  padding: 10px;
}

.loading {
  text-align: center;
  padding: 20px;
  color: #666;
}

.error {
  text-align: center;
  padding: 20px;
  color: #ff4444;
}
</style> 