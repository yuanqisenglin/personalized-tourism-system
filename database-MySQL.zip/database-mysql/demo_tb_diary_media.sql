-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: demo
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_diary_media`
--

DROP TABLE IF EXISTS `tb_diary_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_diary_media` (
  `media_id` int NOT NULL AUTO_INCREMENT,
  `diary_id` int NOT NULL,
  `media_type` varchar(20) DEFAULT NULL,
  `media_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`media_id`),
  UNIQUE KEY `media_id_UNIQUE` (`media_id`),
  KEY `diary_id_media` (`diary_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_diary_media`
--

LOCK TABLES `tb_diary_media` WRITE;
/*!40000 ALTER TABLE `tb_diary_media` DISABLE KEYS */;
INSERT INTO `tb_diary_media` VALUES (50,100081,'视频','http://localhost:9090/uploads/00d0d291-22f6-4706-95a4-f33979f0af76_%E4%B8%89%E4%BA%9A.mp4'),(51,100081,'图片','http://localhost:9090/uploads/d312dc1f-ebef-41c4-b944-982c667f0578_OIP.jpg'),(52,100082,'图片','http://localhost:9090/uploads/f6fd60ca-2ca8-4039-839d-62385effa9e7_OIP.jpg'),(53,100083,'图片','http://localhost:9090/uploads/d18d1f9b-d5e3-464c-9f3b-24ddfdf55020_OIP.jpg'),(54,100085,'图片','http://localhost:9090/uploads/31819d17-9daa-4c58-9ca8-b37c531257a1_OIP.jpg'),(55,100085,'视频','http://localhost:9090/uploads/e48c0abf-e72b-4439-b13e-78ce2136ee83_%E4%B8%89%E4%BA%9A.mp4'),(56,100086,'image/jpeg','http://localhost:9090/uploads/1f112f20-fa30-4d96-8f9f-d952fc52df9e_OIP.jpg'),(57,100087,'image/jpeg','http://localhost:9090/uploads/5472fcd5-12ae-43e4-9e79-711981dff354_1f7b2036-cb71-4dbb-b10e-58390b8f415f.jpg'),(58,100088,'image/jpeg','http://localhost:9090/uploads/1976c09f-5a61-40dc-8515-e57c8cb337a6_OIP.jpg'),(59,100089,'图片','http://localhost:9090/uploads/fab05780-3a7d-4af8-85c0-771719fd8aac_OIP.jpg'),(60,100091,'image','http://localhost:9090/uploads/5be53def-c1e9-4693-9080-bdc4cd8122e2_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20224247.png'),(61,100092,'image','http://localhost:9090/uploads/d298ce63-f4eb-42ee-bc03-98e260ceb17b_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20224247.png'),(62,100093,'image','http://localhost:9090/uploads/b0468a55-8352-4acd-ab97-e360b3a236fd_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20224247.png'),(63,100095,'image','http://localhost:9090/uploads/a7009a5a-f2bd-40fb-a9f5-fa78fcb36a26_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20225205.png'),(64,100096,'image','http://localhost:9090/uploads/3c271b0e-3d53-44df-ac72-bd5ddadd5aa8_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20225205.png'),(65,100097,'image','http://localhost:9090/uploads/3e9e4d46-ab33-47e3-b550-5e5cdca42c05_OIP.jpg'),(66,100097,'video','http://localhost:9090/uploads/61ed0cf0-13ab-44d5-a7c3-da670469fe31_%E4%B8%89%E4%BA%9A.mp4'),(67,100098,'video','http://localhost:9090/uploads/70a2eae6-471e-4c8e-80a0-469f97238cd6_%E4%B8%89%E4%BA%9A.mp4'),(68,100098,'image','http://localhost:9090/uploads/4095c6f8-a4f4-4f2c-bafa-dcba17e0dc17_OIP.jpg'),(69,100100,'image','http://localhost:9090/uploads/8614346f-89bb-4231-ad2c-470e92676b21_OIP.jpg'),(70,100100,'video','http://localhost:9090/uploads/7ac4e2af-415c-4a7c-ac22-fe2e7b9629ac_%E4%B8%89%E4%BA%9A.mp4'),(71,100101,'video','http://localhost:9090/uploads/b33b9ea7-a434-4974-ae53-825f357d5bf1_%E4%B8%89%E4%BA%9A.mp4'),(72,100102,'image','http://localhost:9090/uploads/b4c713c7-85e9-4cd6-8c9d-7b3a02ec34eb_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20220213.png'),(73,100103,'图片','http://localhost:9090/uploads/c878b055-7b29-4f86-aa76-31853c08f299_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20225205.png'),(74,100104,'图片','http://localhost:9090/uploads/e97ab1ec-990a-4b75-bd3e-69fd6bbf8ac2_%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE%202025-03-01%20225205.png'),(75,100104,'视频','http://localhost:9090/uploads/e2b390d5-9984-45e2-8471-ad4f630a56f5_%E4%B8%89%E4%BA%9A.mp4'),(76,100105,'视频','http://localhost:9090/uploads/b2c44998-c245-4e0f-8fb0-1dbfe026d9e2_%E4%B8%89%E4%BA%9A.mp4'),(77,100106,'视频','http://localhost:9090/uploads/03d0326d-3d11-4b9d-9ec2-032efda6558d_%E4%B8%89%E4%BA%9A.mp4'),(78,100107,'视频','http://localhost:9090/uploads/a6b2ec02-b438-404a-8b4f-59e9ec309ced_%E4%B8%89%E4%BA%9A.mp4'),(79,100111,'视频','http://localhost:9090/uploads/d911c8e3-ffac-440c-b3c0-5a563942645a_%E4%B8%89%E4%BA%9A.mp4'),(80,100111,'图片','http://localhost:9090/uploads/acac24ba-1058-4782-b248-8432cb8e6f66_OIP.jpg'),(81,100112,'视频','http://localhost:9090/uploads/13a975e4-2ba7-452e-8486-2f6008c4e5d6_%E4%B8%89%E4%BA%9A.mp4'),(82,100113,'图片','http://localhost:9090/uploads/545b7768-04cc-4dd0-80e9-94777881b5df_OIP.jpg'),(83,100113,'视频','http://localhost:9090/uploads/da917b71-8399-4c8f-8722-bdf36ab2725b_%E4%B8%89%E4%BA%9A.mp4'),(84,100114,'视频','http://localhost:9090/uploads/8676a7a4-bf66-468d-8fb6-ed3b5aecc6ab_%E4%B8%89%E4%BA%9A.mp4'),(85,100114,'图片','http://localhost:9090/uploads/074717f2-86f3-4bfd-b736-18943c9ffe64_OIP.jpg'),(86,100120,'图片','http://localhost:9090/uploads/0bc52f65-171b-4c44-8a6c-c98546f484bd_1f112f20-fa30-4d96-8f9f-d952fc52df9e_OIP.jpg'),(87,100120,'视频','http://localhost:9090/uploads/eb0679d3-f589-49e6-b288-3d6ff5cd6427_00d0d291-22f6-4706-95a4-f33979f0af76_%E4%B8%89%E4%BA%9A.mp4'),(88,100122,'图片','http://localhost:9090/uploads/704f059c-cc35-40f7-b47b-db37dff61562_1f112f20-fa30-4d96-8f9f-d952fc52df9e_OIP.jpg'),(89,100122,'视频','http://localhost:9090/uploads/8f778be8-7171-4a0f-b8f1-b39849877188_03d0326d-3d11-4b9d-9ec2-032efda6558d_%E4%B8%89%E4%BA%9A.mp4'),(90,100125,'图片','http://localhost:9090/uploads/7c952c2d-8e20-44df-a5c3-a638a0db73b4_8f903b315f1863a186d3b51580403161.png'),(91,100125,'视频','http://localhost:9090/uploads/458d75d7-46e5-48d5-ab65-231484e98947_1452452272-1-192.mp4'),(92,100125,'图片','http://localhost:9090/uploads/c68ee882-9f4b-4537-929e-73d14177b0f7_fad95ab755b8b81fad7bc20bf3d4d429.jpeg'),(93,100125,'视频','http://localhost:9090/uploads/07b97be5-2d7a-441d-b6ad-8007f346bc3a_240082741-1-208.mp4'),(94,100136,'视频','http://localhost:9090/uploads/1766fdd7-e697-4050-84f9-4204a876c719_1590251157-1-192.mp4'),(95,100136,'图片','http://localhost:9090/uploads/50b90e5e-6ffe-457b-8449-e7247fa4f7df_20171204051900773.jpg'),(96,100136,'图片','http://localhost:9090/uploads/736faa0f-4e14-480c-8e76-c5f307504236_R-C.jpg'),(97,100152,'视频','http://localhost:9090/uploads/cb33864c-bdde-410f-8e8f-892c00aecff7_07b97be5-2d7a-441d-b6ad-8007f346bc3a_240082741-1-208.mp4'),(98,100153,'图片','http://localhost:9090/uploads/18d0adeb-3017-479d-adcf-6a2ecc7df459_simon-english-48nerZQCHgo-unsplash.jpg'),(99,100154,'图片','http://localhost:9090/uploads/1de9e2af-aabb-4ac6-84c6-9537f89fd676_istockphoto-2160021545-1024x1024.jpg'),(100,100154,'图片','http://localhost:9090/uploads/08c303ff-0986-412c-89ec-d8767df2bc1f_simon-english-48nerZQCHgo-unsplash.jpg'),(101,100155,'视频','http://localhost:9090/uploads/f1638930-b7b0-4042-aa7a-eb92ae1751ea_07b97be5-2d7a-441d-b6ad-8007f346bc3a_240082741-1-208.mp4'),(102,100155,'图片','http://localhost:9090/uploads/eb8100de-8500-4950-84ea-48238225e9ad_istockphoto-2160021545-1024x1024.jpg'),(103,100155,'图片','http://localhost:9090/uploads/e35b804d-da02-4a3e-b0b8-2ea80860c7e4_simon-english-48nerZQCHgo-unsplash.jpg');
/*!40000 ALTER TABLE `tb_diary_media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-02 23:04:25
