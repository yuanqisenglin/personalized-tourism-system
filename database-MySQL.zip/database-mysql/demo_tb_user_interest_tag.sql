-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: demo
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_user_interest_tag`
--

DROP TABLE IF EXISTS `tb_user_interest_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_user_interest_tag` (
  `tag_relation_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(11) NOT NULL,
  `interest_tag` varchar(10) NOT NULL,
  PRIMARY KEY (`tag_relation_id`),
  UNIQUE KEY `tag_relation_id_UNIQUE` (`tag_relation_id`),
  KEY `user_id_idx` (`user_id`),
  CONSTRAINT `user_id_tag` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=150206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_user_interest_tag`
--

LOCK TABLES `tb_user_interest_tag` WRITE;
/*!40000 ALTER TABLE `tb_user_interest_tag` DISABLE KEYS */;
INSERT INTO `tb_user_interest_tag` VALUES (150001,'18923456780','故宫'),(150002,'18923456780','长城'),(150003,'18887654320','北京烤鸭'),(150004,'18887654320','南锣鼓巷'),(150005,'18887654320','天坛'),(150006,'18765432109','颐和园'),(150007,'18765432109','圆明园'),(150008,'18276583410','环球度假区'),(150009,'18276583410','798艺术区'),(150010,'18145678901','奥林匹克公园'),(150011,'18145678901','鸟巢'),(150012,'18145678901','水立方'),(150013,'18145678901','环球度假区'),(150014,'18145678901','长城'),(150015,'17890123456','雍和宫'),(150016,'17312345678','南锣鼓巷'),(150017,'17312345678','北京民俗文化'),(150018,'17089012345','北海公园'),(150019,'17089012345','景山公园'),(150020,'17089012345','摄影打卡'),(150021,'15932167845',' 天坛公园 '),(150022,'15932167845',' 老字号美食 '),(150023,'15932167845',' 时尚购物 '),(150024,'15932167845',' 潮流展览 '),(150025,'15867890123',' 北京动物园 '),(150026,'15867890123',' 天文馆 '),(150027,'15867890123',' 亲子科普活动 '),(150028,'15867890123',' 慕田峪长城 '),(150029,'15867890123',' 户外徒步 '),(150030,'15867890123',' 露营 '),(150031,'15734567890',' 三里屯 '),(150032,'15234567890',' 北京环球度假区 '),(150033,'15234567890',' 哈利・波特主题区 '),(150034,'15234567890',' 花车巡游 '),(150035,'15123456789',' 中国科学技术馆 '),(150036,'15123456789',' 科技探索 '),(150037,'13987654321',' 北京植物园 '),(150038,'13987654321',' 花卉观赏 '),(150039,'13987654321',' 植物科普讲座 '),(150040,'13867549821',' 古代陵墓文化 '),(150041,'13867549821',' 考古发掘参观 '),(150042,'13645897231',' 卢沟桥 '),(150043,'13645897231',' 宛平城 '),(150044,'13578901234',' 红楼文化研读 '),(150045,'13578901234',' 古典园林绘画 '),(150046,'13367890123',' 密云水库 '),(150047,'13367890123',' 水上运动 '),(150048,'13367890123',' 生态摄影 '),(150049,'13367890123',' 创新工作坊 '),(150050,'13256789012',' 北京野生动物园 '),(150051,'13256789012',' 户外野餐 '),(150074,'13256789012','日出日落'),(150093,'13645897231','海洋馆'),(150094,'13645897231','公园'),(150095,'13645897231','博物馆'),(150096,'13645897231','故宫'),(150114,'134','北京邮电大学'),(150144,'178','永定门公园'),(150145,'178','永定门公园'),(150146,'178','北京邮电大学'),(150152,'13578901234','粤菜'),(150153,'13578901234','粤菜'),(150154,'13578901234','粤菜'),(150160,'13578901234','永定门公园'),(150161,'13578901234','永定门公园'),(150162,'13578901234','北京邮电大学'),(150163,'13578901234','北京邮电大学'),(150180,'1256','北京邮电'),(150181,'1256','北京邮电'),(150182,'1256','北京邮电'),(150183,'1256','北京邮电'),(150190,'1256','北京邮电'),(150196,'15570859411','浙菜'),(150197,'15570859411','孔庙'),(150198,'15570859411','北京邮电'),(150199,'15570859411','北京邮电'),(150200,'15570859411','三亚'),(150201,'15570859489','北京邮电'),(150202,'15570859489','浙菜'),(150203,'15570859489','孔庙'),(150204,'15570859489','北京大学'),(150205,'15570859489','孔庙');
/*!40000 ALTER TABLE `tb_user_interest_tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-02 23:04:25
