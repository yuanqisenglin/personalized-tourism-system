-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: demo
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_rating`
--

DROP TABLE IF EXISTS `tb_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_rating` (
  `rating_id` int NOT NULL AUTO_INCREMENT,
  `diary_id` bigint NOT NULL,
  `user_id` varchar(11) NOT NULL,
  `rating` int NOT NULL,
  `rating_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rating_id`),
  KEY `fk_rating_diary` (`diary_id`),
  KEY `fk_rating_user` (`user_id`),
  CONSTRAINT `fk_rating_diary` FOREIGN KEY (`diary_id`) REFERENCES `tb_travel_diary` (`diary_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rating_user` FOREIGN KEY (`user_id`) REFERENCES `tb_user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_rating`
--

LOCK TABLES `tb_rating` WRITE;
/*!40000 ALTER TABLE `tb_rating` DISABLE KEYS */;
INSERT INTO `tb_rating` VALUES (1,100001,'13645897231',4,'2025-05-21 06:09:25'),(2,100001,'13987654321',4,'2025-05-21 06:10:13'),(3,100001,'17890123456',5,'2025-05-21 06:10:34'),(4,100001,'13645897231',4,'2025-05-21 12:29:46'),(5,100001,'13645897231',3,'2025-05-21 12:29:53'),(6,100002,'13645897231',5,'2025-05-21 12:31:06'),(21,100001,'13645897231',5,'2025-05-25 04:36:13'),(22,100001,'13645897231',4,'2025-05-27 10:05:24'),(23,100008,'13645897231',5,'2025-05-27 11:13:40'),(28,100005,'13645897231',5,'2025-05-28 11:12:12'),(34,100035,'13578901234',4,'2025-06-01 10:38:20'),(35,100038,'13578901234',5,'2025-06-01 10:48:14'),(36,100002,'13578901234',4,'2025-06-01 11:17:25'),(37,100002,'13578901234',3,'2025-06-01 11:17:59'),(40,100037,'13578901234',5,'2025-06-01 11:33:14'),(60,100018,'1256',5,'2025-06-01 13:29:47'),(64,100008,'15570859411',4,'2025-06-02 09:06:18'),(65,100033,'15570859411',5,'2025-06-02 09:31:09'),(68,100125,'15570859489',5,'2025-06-02 13:27:06'),(69,100125,'15570859489',5,'2025-06-02 13:27:08'),(70,100125,'15570859489',4,'2025-06-02 13:27:11'),(71,100124,'15570859489',4,'2025-06-02 13:35:33'),(72,100134,'18923456780',4,'2025-06-02 13:49:34'),(73,100135,'18923456780',3,'2025-06-02 13:50:28'),(74,100135,'18923456780',2,'2025-06-02 13:50:30'),(75,100135,'18923456780',2,'2025-06-02 13:50:35'),(76,100135,'18923456780',3,'2025-06-02 13:50:38'),(77,100125,'18923456780',5,'2025-06-02 13:51:24'),(78,100126,'18923456780',3,'2025-06-02 13:51:50'),(79,100127,'18923456780',3,'2025-06-02 13:52:11'),(80,100129,'18923456780',4,'2025-06-02 13:52:21'),(81,100133,'18923456780',3,'2025-06-02 13:52:30'),(82,100130,'18923456780',5,'2025-06-02 13:52:44'),(83,100130,'18923456780',1,'2025-06-02 13:52:47'),(84,100130,'18923456780',2,'2025-06-02 13:52:49'),(85,100131,'18923456780',4,'2025-06-02 13:52:58'),(86,100131,'18923456780',3,'2025-06-02 13:53:00'),(87,100131,'18923456780',2,'2025-06-02 13:53:02'),(88,100131,'18923456780',3,'2025-06-02 13:53:04'),(89,100131,'18923456780',4,'2025-06-02 13:53:06'),(90,100132,'18923456780',2,'2025-06-02 13:53:26'),(91,100132,'18923456780',1,'2025-06-02 13:53:29'),(92,100132,'18923456780',4,'2025-06-02 13:53:32'),(93,100136,'15570859489',5,'2025-06-02 14:18:53'),(94,100137,'13578901234',4,'2025-06-02 14:42:54'),(95,100137,'13578901234',5,'2025-06-02 14:42:57'),(96,100138,'13578901234',3,'2025-06-02 14:43:29'),(97,100139,'13578901234',2,'2025-06-02 14:43:39'),(98,100139,'13578901234',4,'2025-06-02 14:43:42'),(99,100139,'13578901234',3,'2025-06-02 14:43:44'),(100,100139,'13578901234',5,'2025-06-02 14:43:46'),(101,100140,'13578901234',4,'2025-06-02 14:43:54'),(102,100140,'13578901234',3,'2025-06-02 14:43:56'),(103,100141,'13578901234',5,'2025-06-02 14:44:05'),(104,100141,'13578901234',1,'2025-06-02 14:44:08'),(105,100141,'13578901234',3,'2025-06-02 14:44:09'),(106,100141,'13578901234',2,'2025-06-02 14:44:12'),(107,100142,'13578901234',5,'2025-06-02 14:44:21'),(108,100142,'13578901234',1,'2025-06-02 14:44:24'),(109,100142,'13578901234',5,'2025-06-02 14:44:26'),(110,100143,'13578901234',4,'2025-06-02 14:44:36'),(111,100143,'13578901234',3,'2025-06-02 14:44:38'),(112,100143,'13578901234',5,'2025-06-02 14:44:39'),(113,100143,'13578901234',3,'2025-06-02 14:44:42'),(114,100144,'13578901234',4,'2025-06-02 14:44:50'),(115,100144,'13578901234',5,'2025-06-02 14:44:52'),(116,100144,'13578901234',3,'2025-06-02 14:44:54'),(117,100144,'13578901234',4,'2025-06-02 14:44:57'),(118,100144,'13578901234',3,'2025-06-02 14:44:59');
/*!40000 ALTER TABLE `tb_rating` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_diary_rating_insert` AFTER INSERT ON `tb_rating` FOR EACH ROW BEGIN
    UPDATE tb_travel_diary
    JOIN (SELECT diary_id, AVG(rating) AS avg_rating FROM tb_rating WHERE diary_id = NEW.diary_id GROUP BY diary_id) AS r
    ON tb_travel_diary.diary_id = r.diary_id
    SET tb_travel_diary.rating = r.avg_rating;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_diary_rating_update` AFTER UPDATE ON `tb_rating` FOR EACH ROW BEGIN
    IF OLD.diary_id = NEW.diary_id THEN
        UPDATE tb_travel_diary
        JOIN (SELECT diary_id, AVG(rating) AS avg_rating FROM tb_rating WHERE diary_id = NEW.diary_id GROUP BY diary_id) AS r
        ON tb_travel_diary.diary_id = r.diary_id
        SET tb_travel_diary.rating = r.avg_rating;
    ELSE
        -- 更新原日记
        UPDATE tb_travel_diary
        JOIN (SELECT diary_id, AVG(rating) AS avg_rating FROM tb_rating WHERE diary_id = OLD.diary_id GROUP BY diary_id) AS r_old
        ON tb_travel_diary.diary_id = r_old.diary_id
        SET tb_travel_diary.rating = r_old.avg_rating;
        -- 更新新日记
        UPDATE tb_travel_diary
        JOIN (SELECT diary_id, AVG(rating) AS avg_rating FROM tb_rating WHERE diary_id = NEW.diary_id GROUP BY diary_id) AS r_new
        ON tb_travel_diary.diary_id = r_new.diary_id
        SET tb_travel_diary.rating = r_new.avg_rating;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-02 23:04:25
