package com.example.place.dto;

public class NearestBuildingDTO {
    private String apartmentName;
    private double distanceMeters;

    public NearestBuildingDTO(String apartmentName, double distanceMeters) {
        this.apartmentName = apartmentName;
        this.distanceMeters = distanceMeters;
    }

    public String getApartmentName() {
        return apartmentName;
    }

    public void setApartmentName(String apartmentName) {
        this.apartmentName = apartmentName;
    }

    public double getDistanceMeters() {
        return distanceMeters;
    }

    public void setDistanceMeters(double distanceMeters) {
        this.distanceMeters = distanceMeters;
    }
}
