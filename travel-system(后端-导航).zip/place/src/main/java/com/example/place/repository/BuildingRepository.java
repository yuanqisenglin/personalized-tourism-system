package com.example.place.repository;

import com.example.place.entity.Building;
import com.example.place.dto.NearestBuildingDTO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

@Repository
public interface BuildingRepository extends CrudRepository<Building, Long> {

    @Query(value = """
    WITH nearest_targets AS ( 
      SELECT DISTINCT
        b1.name AS start_name,
        b2.name AS target_name,
        ST_Distance(
          ST_Transform(ST_Centroid(b1.geom), 3857),
          ST_Transform(ST_Centroid(b2.geom), 3857)
        ) AS distance_meters
      FROM buildings b1
      JOIN buildings b2 ON b1.name = :startName
      WHERE b2.type = :targetType
        AND b1.building_id != b2.building_id
    )
    SELECT target_name, distance_meters
    FROM nearest_targets
    ORDER BY distance_meters 
    LIMIT :limit
    """, nativeQuery = true)
    List<Object[]> findNearestTargets(
            @Param("startName") String startName,
            @Param("targetType") String targetType,
            @Param("limit") int limit
    );

}
