package com.example.place.service;

import com.example.place.dto.PathRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PathPlanningService {

    @Autowired
    JdbcTemplate jdbcTemplate;

    ObjectMapper mapper = new ObjectMapper();

    public String calculateFullPath(PathRequest request) throws JsonProcessingException {
        List<String> names = new ArrayList<>();
        if (request.getStart() != null) names.add(request.getStart());
        if (request.getVia() != null) names.addAll(request.getVia());
        if (request.getEnd() != null) names.add(request.getEnd());

        List<ObjectNode> features = new ArrayList<>();
        List<Integer> nodeIds = new ArrayList<>();
        Map<Integer, String> nodeIdToLabelName = new HashMap<>();

        for (String name : names) {
            Map<String, Object> row = jdbcTemplate.queryForMap("""
                WITH building_geom AS (
                    SELECT ST_Centroid(geom) AS geom
                    FROM buildings
                    WHERE name = ? LIMIT 1
                ),
                nearest_node AS (
                    SELECT id, geom AS node_geom
                    FROM intersection_nodes
                    ORDER BY geom <-> (SELECT geom FROM building_geom)
                    LIMIT 1
                )
                SELECT ST_AsGeoJSON(ST_MakeLine(b.geom, n.node_geom)) AS geom_json,
                       ST_Distance(b.geom, n.node_geom) AS cost,
                       n.id AS target
                FROM building_geom b, nearest_node n;
            """, name);

            ObjectNode connector = mapper.createObjectNode();
            connector.put("type", "Feature");
            connector.set("geometry", mapper.readTree((String) row.get("geom_json")));
            ObjectNode props = connector.putObject("properties");
            props.put("type", "connector");
            props.put("name", name);
            props.put("cost", ((Number) row.get("cost")).doubleValue());
            features.add(connector);

            int nid = ((Number) row.get("target")).intValue();
            nodeIds.add(nid);
            nodeIdToLabelName.put(nid, name);
        }

        if (nodeIds.size() < 2) throw new RuntimeException("请至少填写起点和终点");

        int source = nodeIds.get(0);
        int target = nodeIds.get(nodeIds.size() - 1);
        List<Integer> via = nodeIds.subList(1, nodeIds.size() - 1);

        List<Integer> bestPath = null;
        double bestCost = Double.POSITIVE_INFINITY;
        List<Integer> bestNodeSequence = null;

        List<List<Integer>> permutations = permute(via);

        String costField;
        String condition;
        String mode = request.getMode();
        String tool = request.getTool();

        if ("walk".equals(tool)) {
            costField = "walk_cost";
            condition = "foot = true";
        } else if ("bike".equals(tool)) {
            costField = "bike_cost";
            condition = "bicycle = true";
        } else if ("ebike".equals(tool)) {
            costField = "ebike_cost";
            condition = "ebike = true";
        } else if ("auto".equals(tool)) {
            if ("campus".equals(mode)) {
                costField = "CASE WHEN bicycle THEN bike_cost ELSE walk_cost END";
                condition = "foot = true OR bicycle = true";
            } else {
                costField = "CASE WHEN ebike THEN ebike_cost ELSE walk_cost END";
                condition = "foot = true OR ebike = true";
            }
        } else {
            throw new RuntimeException("未知交通方式");
        }

        for (List<Integer> perm : permutations) {
            List<Integer> path = new ArrayList<>();
            path.add(source);
            path.addAll(perm);
            path.add(target);

            double totalCost = 0;
            boolean valid = true;
            List<Map<String, Object>> allEdges = new ArrayList<>();

            for (int i = 0; i < path.size() - 1; i++) {
                int s = path.get(i);
                int t = path.get(i + 1);

                String dijkstraSql = String.format("""
                    SELECT seq, edge, cost FROM pgr_dijkstra(
                      'SELECT id, source, target, %s AS cost FROM segmented_path_network WHERE %s AND source IS NOT NULL AND target IS NOT NULL',
                      ?, ?, directed := false
                    ) ORDER BY seq
                """, costField, condition);

                List<Map<String, Object>> part = jdbcTemplate.queryForList(dijkstraSql, s, t);
                if (part.isEmpty()) {
                    valid = false;
                    break;
                }

                totalCost += part.stream().mapToDouble(e -> ((Number) e.get("cost")).doubleValue()).sum();
                allEdges.addAll(part);
            }

            if (valid && totalCost < bestCost) {
                bestCost = totalCost;
                bestPath = allEdges.stream()
                        .map(e -> ((Number) e.get("edge")).intValue())
                        .collect(Collectors.toList());
                bestNodeSequence = new ArrayList<>(path);
            }
        }

        if (bestPath == null || bestPath.isEmpty())
            throw new RuntimeException("未找到有效路径");

        // 添加排序后的标签（包括重复地点）
        for (int i = 0; i < bestNodeSequence.size(); i++) {
            int nid = bestNodeSequence.get(i);
            String name = nodeIdToLabelName.get(nid);
            if (name == null) continue;
            String label;
            if (i == 0 && i == bestNodeSequence.size() - 1) {
                label = "起点、终点：" + name;
            } else if (i == 0) {
                label = "起点：" + name;
            } else if (i == bestNodeSequence.size() - 1) {
                label = "终点：" + name;
            } else {
                label = "途径" + i + "：" + name;
            }

            ObjectNode marker = mapper.createObjectNode();
            marker.put("type", "Feature");
            ObjectNode props = marker.putObject("properties");
            props.put("type", "label");
            props.put("label", label);
            props.put("node_id", nid);
            features.add(marker);
        }

        // 查询路径段，增加foot, bicycle, ebike字段
        String geoQuery = "SELECT id, ST_AsGeoJSON(geom) AS geom_json, name, cost, source, target, path_id, foot, bicycle, ebike " +
                "FROM segmented_path_network WHERE id IN (" +
                bestPath.stream().map(String::valueOf).collect(Collectors.joining(",")) + ")";
        List<Map<String, Object>> segments = jdbcTemplate.queryForList(geoQuery);

        Set<Integer> intersectionIds = new HashSet<>(jdbcTemplate.queryForList("SELECT id FROM intersection_nodes", Integer.class));

        Map<Integer, Map<String, Object>> segmentMap = new HashMap<>();
        for (Map<String, Object> r : segments) {
            segmentMap.put(((Number) r.get("id")).intValue(), r);
        }

        int order = 0;
        for (int i = 0; i < bestPath.size(); i++) {
            int eid = bestPath.get(i);
            Map<String, Object> r = segmentMap.get(eid);
            if (r == null) continue;

            int src = ((Number) r.get("source")).intValue();
            int tgt = ((Number) r.get("target")).intValue();
            int pathId = r.get("path_id") != null ? ((Number) r.get("path_id")).intValue() : -1;

            boolean isFirst = (i == 0);
            boolean isLast = (i == bestPath.size() - 1);

            if (!(isFirst || isLast)) {
                if (pathId <= 0 || !intersectionIds.contains(src) || !intersectionIds.contains(tgt)) {
                    continue;
                }
            }

            ObjectNode f = mapper.createObjectNode();
            f.put("type", "Feature");
            f.set("geometry", mapper.readTree((String) r.get("geom_json")));
            ObjectNode p = f.putObject("properties");
            p.put("type", isFirst || isLast ? "connector" : "path");
            p.put("name", r.get("name") != null ? r.get("name").toString() : "");
            p.put("cost", ((Number) r.get("cost")).doubleValue());
            p.put("source", src);
            p.put("target", tgt);
            p.put("segment_order", order++);

            // 新增交通工具字段
            p.put("foot", (Boolean) r.get("foot"));
            p.put("bicycle", (Boolean) r.get("bicycle"));
            p.put("ebike", (Boolean) r.get("ebike"));

            features.add(f);
        }

        ObjectNode fc = mapper.createObjectNode();
        fc.put("type", "FeatureCollection");
        fc.set("features", mapper.valueToTree(features));
        return fc.toPrettyString();
    }

    private List<List<Integer>> permute(List<Integer> input) {
        List<List<Integer>> res = new ArrayList<>();
        if (input.isEmpty()) {
            res.add(new ArrayList<>());
            return res;
        }
        for (int i = 0; i < input.size(); i++) {
            Integer head = input.get(i);
            List<Integer> rest = new ArrayList<>(input);
            rest.remove(i);
            for (List<Integer> perm : permute(rest)) {
                List<Integer> newPerm = new ArrayList<>();
                newPerm.add(head);
                newPerm.addAll(perm);
                res.add(newPerm);
            }
        }
        return res;
    }
}
