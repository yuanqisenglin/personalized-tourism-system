package com.example.place.controller;

import com.example.place.repository.BuildingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/buildings")
@CrossOrigin(origins = "*")  // 允许前端跨域请求
public class BuildingmatchController {

    @Autowired
    private BuildingRepository buildingRepository;

    @GetMapping("/nearest")
    public ResponseEntity<List<Map<String, Object>>> getNearestBuildings(
            @RequestParam String startName,
            @RequestParam String targetType,
            @RequestParam(defaultValue = "5") int limit) {

        List<Object[]> results = buildingRepository.findNearestTargets(startName, targetType, limit);

        List<Map<String, Object>> response = results.stream().map(row -> {
            Map<String, Object> map = new HashMap<>();
            map.put("targetName", row[0]);          // 设施名称
            map.put("distanceMeters", row[1]);      // 距离（米）
            return map;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }


}
