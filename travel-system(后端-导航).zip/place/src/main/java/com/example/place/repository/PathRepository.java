package com.example.place.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;

@Repository
public class PathRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 查询起点到终点的最短路径（Dijkstra算法），
     * 返回GeoJSON格式的路径集合，
     * 每个路径段附带foot, bicycle, ebike字段，表明该路段支持的交通方式。
     *
     * @param start 起点节点ID
     * @param end 终点节点ID
     * @return GeoJSON字符串
     */
    public String getDijkstraGeoJson(int start, int end) {
        String sql = String.format(
                "SELECT jsonb_build_object(\n" +
                        "  'type', 'FeatureCollection',\n" +
                        "  'features', jsonb_agg(\n" +
                        "    jsonb_build_object(\n" +
                        "      'type', 'Feature',\n" +
                        "      'geometry', ST_AsGeoJSON(sp.geom)::jsonb,\n" +
                        "      'properties', jsonb_build_object(\n" +
                        "        'id', sp.id,\n" +
                        "        'name', sp.name,\n" +
                        "        'type', 'segment',\n" +
                        "        'foot', sp.foot,\n" +
                        "        'bicycle', sp.bicycle,\n" +
                        "        'ebike', sp.ebike\n" +
                        "      )\n" +
                        "    )\n" +
                        "  )\n" +
                        ") AS geojson\n" +
                        "FROM pgr_dijkstra(\n" +
                        "  'SELECT id, source, target, cost FROM segmented_path_network', %d, %d, false\n" +
                        ") dj\n" +
                        "JOIN segmented_path_network sp ON dj.edge = sp.id",
                start, end
        );
        return jdbcTemplate.queryForObject(sql, String.class);
    }

    /**
     * 根据建筑物名称，查找距离最近的节点ID。
     * @param name 建筑物名称
     * @return 最近节点ID
     */
    public Integer findNearestNodeByBuilding(String name) {
        String sql = "SELECT n.id FROM buildings b, intersection_nodes n " +
                "WHERE b.name = ? ORDER BY n.geom <-> ST_Centroid(b.geom) LIMIT 1";
        return jdbcTemplate.queryForObject(sql, new Object[]{name}, Integer.class);
    }
}
