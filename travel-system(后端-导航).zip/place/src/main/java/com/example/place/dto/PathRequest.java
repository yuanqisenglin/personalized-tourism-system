package com.example.place.dto;

import java.util.List;

public class PathRequest {
    private String start;
    private String end;
    private List<String> via;
    private String mode; // campus / scenic
    private String tool; // walk / bike / ebike / time

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public List<String> getVia() {
        return via;
    }

    public void setVia(List<String> via) {
        this.via = via;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getTool() {
        return tool;
    }

    public void setTool(String tool) {
        this.tool = tool;
    }
}
