package com.example.place.controller;

import com.example.place.dto.PathRequest;
import com.example.place.service.PathPlanningService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/route")
public class PathPlanningController {

    @Autowired
    private PathPlanningService service;

    /**
     * 使用POST请求接收路径规划请求，参数为JSON格式的PathRequest
     * 调用PathPlanningService计算路径，返回GeoJSON格式的路线结果
     *
     * @param request 前端发送的路径请求参数，包括起点、终点、途经点、交通工具和模式
     * @return GeoJSON格式字符串，包含路径线段和连接点的空间信息
     */
    @PostMapping("/dijkstra")
    public String getRoute(@RequestBody PathRequest request) throws JsonProcessingException {
        return service.calculateFullPath(request);
    }
}
