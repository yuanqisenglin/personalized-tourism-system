package com.example.place.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/intersections")
public class IntersectionNodeController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/geojson")
    public String getAllIntersectionNodes() {
        String sql = """
            SELECT jsonb_build_object(
              'type', 'FeatureCollection',
              'features', jsonb_agg(
                jsonb_build_object(
                  'type', 'Feature',
                  'geometry', ST_AsGeoJSON(geom)::jsonb,
                  'properties', jsonb_build_object('id', id, 'way_ids', path_way_ids)
                )
              )
            )
            FROM intersection_nodes;
        """;

        return jdbcTemplate.queryForObject(sql, String.class);
    }
}
