package com.example.place.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/buildings")
public class BuildingController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/geojson")
    public String getAllBuildingsGeoJson() {
        String sql = "SELECT jsonb_build_object(" +
                "  'type', 'FeatureCollection'," +
                "  'features', jsonb_agg(" +
                "    jsonb_build_object(" +
                "      'type', 'Feature'," +
                "      'geometry', ST_AsGeoJSON(geom)::jsonb," +
                "      'properties', jsonb_build_object(" +
                "         'name', name, 'type', type" +
                "      )" +
                "    )" +
                "  )" +
                ") AS geojson FROM buildings;";
        return jdbcTemplate.queryForObject(sql, String.class);
    }
}
